// ===== auth.js =====
// Cloud ACCOUNT layer, powered by Supabase (https://supabase.com). Handles
// sign up / sign in / sign out and keeps state.user in sync with whoever's
// currently logged in.
//
// Also owns the profile <-> cloud, boats <-> cloud, crew <-> cloud and noticeboard <-> cloud sync
// (push-on-edit, pull-and-merge on sign-in, boot-time session restore, and
// the manual "Sync Now" button). Journeys are NOT synced yet — that's the
// next feature to build, following the same shape as boats/crew.
//
// state.user is null when signed out, or { id, email } when signed in.
// Set only by applySession() below — read it elsewhere in the app once we
// start building features that depend on being logged in.

// Project keys from your Supabase dashboard (Settings → API). The
// "publishable" key is safe to ship in frontend code — Supabase enforces
// actual security through Row Level Security policies on the database, not
// by keeping this key secret. Never put the "secret" key here.
const SUPABASE_URL = 'https://opejqowgcjltanvgxmxn.supabase.co';
const SUPABASE_PUBLISHABLE_KEY = 'sb_publishable_GGREMl8C6rbCIkn0k7GVog_yCLJLtz9';

let _supabaseClient = null;
// Built lazily on first use rather than at file-load time — harmless either
// way now that the library loads as a normal blocking script (see
// index.html), but keeping it lazy costs nothing and avoids creating a
// client before it's actually needed.
function getSupabaseClient(){
  if(!_supabaseClient){
    // Safety net: if the bundled library somehow didn't load, fail with a
    // readable message instead of the raw "supabase is not defined".
    if(typeof supabase === 'undefined' || !supabase.createClient){
      throw new Error('Could not start the sign-in service. Please close the app completely and reopen it.');
    }
    // The device's WebView was serving a stale, months-old cached response
    // for these GET requests no matter what — turned out to be the WebView's
    // own HTTP cache (now disabled directly in MainActivity.java) rather
    // than anything reachable from JS. What's left here is just belt-and-
    // suspenders no-cache headers, plus a fix for a real bug: Supabase's
    // Headers object doesn't survive object-spread, which was silently
    // stripping the apikey/Authorization headers off every request.
    _supabaseClient = supabase.createClient(SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY, {
      global: {
        fetch: (url, options) => {
          // Build headers via the real Headers API rather than object-spread —
          // spreading a genuine Headers instance (as opposed to a plain {}
          // object) silently produces an empty object, since Headers doesn't
          // expose its entries as regular enumerable properties. That
          // dropped Supabase's own apikey/Authorization headers entirely,
          // causing every request to fail with "No API key found in
          // request". The Headers constructor correctly merges regardless
          // of whether the input was a plain object or a Headers instance.
          const headers = new Headers((options && options.headers) || {});
          headers.set('Cache-Control', 'no-cache');
          headers.set('Pragma', 'no-cache');
          return fetch(url, {
            ...options,
            cache: 'no-store',
            headers
          });
        }
      }
    });
  }
  return _supabaseClient;
}

// Serializes every cloud read/write for profile/boats/crew through one
// queue, so a push or delete can never be "overtaken" by a pull that
// started a moment later (or vice versa). Without this, deleting a boat
// and then syncing in quick succession could let the pull's SELECT run
// before the delete's tombstone write had actually landed — the pull would
// see the still-there row, and since this device no longer has it locally,
// pull it right back in. Every entry point below (push, delete, and the
// resolve*SyncOnSignIn functions) goes through this queue; the "Impl"
// versions they call internally do NOT re-enter it, since resolve* already
// holds the queue's single slot while it runs and re-entering would
// deadlock (the queued push would wait for a turn that can't come until
// resolve* — which is waiting on that same push — finishes).
let _cloudSyncQueue = Promise.resolve();
function withCloudSyncQueue(fn){
  const run = _cloudSyncQueue.then(fn, fn);
  _cloudSyncQueue = run.catch(()=>{}); // swallow so one failure doesn't wedge the queue
  return run;
}

let authMode = 'signin'; // 'signin' | 'signup' — which mode sheetAuth is currently showing

/* ---------- email-link deep link (Android app) ----------
   Supabase's confirmation email link first verifies the account on
   Supabase's servers, then redirects to `emailRedirectTo`. In the installed
   Android app that's a custom link, saillavie://auth-callback, which Android
   hands to this app thanks to the <intent-filter> on MainActivity in
   android/app/src/main/AndroidManifest.xml. The link carries the new
   session, which we hand to Supabase so the person lands signed in.

   Two ways the link can arrive:
     - app fully closed  → App.getLaunchUrl() at boot (called from initAuth)
     - app already open / in background → the 'appUrlOpen' event
   Both formats Supabase may use are handled: tokens in the #fragment
   (implicit flow, supabase-js's default) or ?code=… (PKCE flow).

   IMPORTANT: saillavie://auth-callback must be listed under Supabase →
   Authentication → URL Configuration → Redirect URLs, or Supabase ignores
   emailRedirectTo and falls back to the Site URL.

   TODO (iOS): when the iPhone native build is started, the same link needs
   registering on iOS too (CFBundleURLTypes in ios/App/App/Info.plist with the
   `saillavie` scheme). The JS below already works for both platforms. */
const AUTH_DEEP_LINK = 'saillavie://auth-callback';

function isNativeAuthPlatform(){
  return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
}

// Where the confirmation link should send people after Supabase verifies them.
function authRedirectUrl(){
  if(isNativeAuthPlatform()) return AUTH_DEEP_LINK;
  // Web / iPhone home-screen version: back to wherever the app is hosted
  // (the GitHub Pages address), minus any file name like index.html.
  return location.origin + location.pathname.replace(/[^/]*$/, '');
}

let _lastAuthDeepLink = null;
// Returns true if the link was ours and a session was created from it.
async function handleAuthDeepLink(url, {runSync} = {runSync:true}){
  if(!url || !url.startsWith(AUTH_DEEP_LINK)) return false;
  if(url === _lastAuthDeepLink) return false; // same link delivered twice — ignore
  _lastAuthDeepLink = url;

  // Tokens can be in the #fragment or the ?query — gather both.
  const params = new URLSearchParams();
  const hashIdx = url.indexOf('#');
  const qIdx = url.indexOf('?');
  if(qIdx !== -1) new URLSearchParams(url.slice(qIdx + 1, hashIdx > qIdx ? hashIdx : undefined)).forEach((v,k)=>params.set(k,v));
  if(hashIdx !== -1) new URLSearchParams(url.slice(hashIdx + 1)).forEach((v,k)=>params.set(k,v));

  try{
    const errMsg = params.get('error_description') || params.get('error');
    if(errMsg){
      // e.g. an expired or already-used link
      showToast(errMsg.replace(/\+/g,' ') + ' — try signing in.');
      return false;
    }
    const client = getSupabaseClient();
    if(params.get('code')){
      const { error } = await client.auth.exchangeCodeForSession(params.get('code'));
      if(error) throw error;
    } else if(params.get('access_token') && params.get('refresh_token')){
      const { error } = await client.auth.setSession({
        access_token: params.get('access_token'),
        refresh_token: params.get('refresh_token')
      });
      if(error) throw error;
    } else {
      return false; // nothing usable in the link
    }
    closeSheets();
    hideWelcomeGate();
    if(runSync){
      // Same first-sign-in sync as signing in by hand.
      await resolveProfileSyncOnSignIn();
      await resolveBoatsSyncOnSignIn();
      await resolveCrewSyncOnSignIn();
      await resolveTripsSyncOnSignIn();
      await resolveNoticeboardSyncOnSignIn();
    }
    showToast('Email confirmed — you\'re signed in.');
    return true;
  } catch(e){
    console.error('auth deep link failed', e);
    showToast('Email confirmed. Please sign in.');
    return false;
  }
}

async function setupAuthDeepLinks(){
  if(!isNativeAuthPlatform()) return; // web handles its own link automatically
  const AppPlugin = window.Capacitor.Plugins && window.Capacitor.Plugins.App;
  if(!AppPlugin) return;
  // App already running → link arrives as an event.
  AppPlugin.addListener('appUrlOpen', (e) => {
    handleAuthDeepLink(e && e.url).catch(err => console.error(err));
  });
  // App was closed → link is the launch URL. initAuth()'s own boot sync
  // runs straight after this, so skip the sync here.
  try{
    const launch = await AppPlugin.getLaunchUrl();
    if(launch && launch.url) await handleAuthDeepLink(launch.url, {runSync:false});
  } catch(e){ console.error('getLaunchUrl failed', e); }
}

/* ---------- boot-time session check ----------
   Called once from boot() in state-core.js (not awaited there — see the
   comment at that call site). Checks whether a session already exists (e.g.
   the app was closed and reopened after a previous login) and subscribes to
   future auth changes so state.user + the Settings screen stay correct
   whenever the session changes (sign in, sign out, token refresh). */
async function initAuth(){
  // If the app was launched by tapping the confirmation link (app was fully
  // closed), turn that link into a signed-in session FIRST, so the session
  // check below finds it and the welcome gate never shows. The normal
  // boot-time sync below then runs for it, so no extra sync here.
  await setupAuthDeepLinks();

  const { data } = await getSupabaseClient().auth.getSession();
  applySession(data.session);

  if(data.session){
    // Silent pull on a restored session, so edits made on another device
    // while this one was closed show up without the person having to sign
    // out/in again or remember to tap "Sync Now". Relies on boot() in
    // state-core.js having already loaded local boats/profile from storage
    // before calling initAuth() — see the comment there. Same resolve
    // functions as an explicit sign-in: silent when there's nothing to
    // conflict with, a confirm prompt only if the cloud and local profile
    // genuinely differ.
    resolveProfileSyncOnSignIn().catch(e => console.error('boot-time profile sync failed', e));
    resolveBoatsSyncOnSignIn().catch(e => console.error('boot-time boats sync failed', e));
    resolveCrewSyncOnSignIn().catch(e => console.error('boot-time crew sync failed', e));
    resolveTripsSyncOnSignIn().catch(e => console.error('boot-time trips sync failed', e));
    resolveNoticeboardSyncOnSignIn().catch(e => console.error('boot-time noticeboard sync failed', e));
  }

  getSupabaseClient().auth.onAuthStateChange((_event, session) => {
    applySession(session);
  });
}

function applySession(session){
  state.user = session ? { id: session.user.id, email: session.user.email } : null;
  renderAccountUI();
  ensureRealtimeSync();
  if(typeof onFriendsSessionChanged === 'function') onFriendsSessionChanged(); // friends.js
  if(session) hideWelcomeGate(); // signed in (from the gate or otherwise) — nothing left to ask
}

/* ---------- welcome gate ----------
   When the app opens and nobody is signed in, #welcomeGate asks them to sign in or create an account
   first. It is shown once per app start (boot() calls showWelcomeGateIfSignedOut after the session
   check) and goes away when they sign in, or tap "Continue without an account" — a TEMPORARY
   escape hatch for evaluating the app (remove that button when accounts become mandatory). The
   choice isn't remembered, so the gate returns on the next launch until someone is signed in. */
function showWelcomeGateIfSignedOut(){
  if(!state.user) document.getElementById('welcomeGate').classList.add('show');
}
function hideWelcomeGate(){
  const el = document.getElementById('welcomeGate');
  if(el) el.classList.remove('show');
}
function welcomeSignIn(){ openAuthSheet('signin'); }
function welcomeSignUp(){ openAuthSheet('signup'); }
function dismissWelcomeGate(){ hideWelcomeGate(); }

/* ---------- live sync across devices (Supabase Realtime) ----------
   Without this, profile/boats/crew only ever re-pull from the cloud at
   sign-in, boot-time session restore, or the manual "Sync Now" button — an
   app left open on another device never notices a change made elsewhere.
   This subscribes to Postgres change notifications on the three synced
   tables (scoped to this user's own rows, same as the RLS policies already
   enforce) and re-runs the existing resolve*SyncOnSignIn merge whenever a
   row changes — so a boat added on the phone shows up on an already-open
   tablet within about a second, no reopen or manual tap required.
   NOTE: this requires each of the "boats", "crew", and "profiles" tables to
   have Realtime replication turned on in the Supabase dashboard (Database →
   Replication → toggle the table on, or
   `alter publication supabase_realtime add table boats;` etc. in the SQL
   editor) — the subscription below silently receives nothing otherwise. */
let _realtimeChannel = null;
let _friendsChannel = null;
let _realtimeUserId = null;
const _realtimeResyncTimers = {};

// ---- on-screen debug overlay ----
// console.log isn't reliably reaching Logcat or chrome://inspect on some
// older Android WebViews (confirmed on an Android 7/API 24 test tablet), so
// this writes straight to a small on-screen panel instead — no dependency
// on any external debugging tool. Set SHOW_SYNC_DEBUG = false once realtime
// sync is confirmed working, to hide this from real users.
// Flipped off 18 Sep 2026 — realtime sync is confirmed working, so the
// on-screen 🐛 toggle and log panel no longer appear. debugLog() calls
// throughout this file are left in place (harmless no-ops via the early
// return below) in case sync needs troubleshooting again later.
const SHOW_SYNC_DEBUG = false;
function debugLog(msg){
  console.log(msg); // kept in case a device *does* forward it
  if(!SHOW_SYNC_DEBUG) return;

  // Small tap-to-open toggle, pinned to the middle of the right edge — out
  // of the way of every header button and bottom-nav item we've hit so far.
  // The log panel itself only appears once you tap the toggle, and starts
  // hidden again on every fresh app launch, so it never sits in front of
  // whatever you're trying to tap next.
  let toggle = document.getElementById('syncDebugToggle');
  let panel = document.getElementById('syncDebugOverlay');
  if(!toggle){
    toggle = document.createElement('div');
    toggle.id = 'syncDebugToggle';
    toggle.textContent = '🐛';
    toggle.style.cssText = 'position:fixed;right:0;top:50%;transform:translateY(-50%);'
      + 'background:rgba(0,0,0,0.55);color:#0f0;font-size:16px;line-height:1;padding:6px 4px;'
      + 'border-radius:6px 0 0 6px;z-index:100000;';
    toggle.onclick = () => { panel.style.display = (panel.style.display === 'none') ? 'block' : 'none'; };
    document.body.appendChild(toggle);

    panel = document.createElement('div');
    panel.id = 'syncDebugOverlay';
    panel.style.cssText = 'position:fixed;left:0;right:0;top:0;max-height:40vh;overflow-y:auto;'
      + 'background:rgba(0,0,0,0.9);color:#0f0;font:10px/1.35 monospace;padding:4px 6px;z-index:99999;'
      + 'white-space:pre-wrap;display:none;'; // hidden until the toggle is tapped
    document.body.appendChild(panel);
  }
  const line = document.createElement('div');
  line.textContent = `${new Date().toLocaleTimeString()}  ${msg}`;
  panel.appendChild(line);
  while(panel.childNodes.length > 40) panel.removeChild(panel.firstChild);
  panel.scrollTop = panel.scrollHeight;
}

// Called from applySession() on every sign-in, boot-time session restore,
// and auth state change (including token refreshes) — guarded so a
// same-user re-call (e.g. token refresh) doesn't tear down and rebuild the
// channel for no reason, and a sign-out (state.user null) tears it down.
function ensureRealtimeSync(){
  if(!state.user){ teardownRealtimeSync(); return; }
  if(_realtimeChannel && _realtimeUserId === state.user.id) return; // already live for this user
  teardownRealtimeSync();
  _realtimeUserId = state.user.id;
  debugLog('[realtime] connecting for user ' + state.user.id);
  _realtimeChannel = getSupabaseClient()
    .channel(`sync-${state.user.id}`)
    .on('postgres_changes', { event: '*', schema: 'public', table: 'boats', filter: `user_id=eq.${state.user.id}` },
      (payload) => { debugLog('[realtime] boats event: ' + payload.eventType); scheduleRealtimeResync('boats'); })
    .on('postgres_changes', { event: '*', schema: 'public', table: 'crew', filter: `user_id=eq.${state.user.id}` },
      (payload) => { debugLog('[realtime] crew event: ' + payload.eventType); scheduleRealtimeResync('crew'); })
    .on('postgres_changes', { event: '*', schema: 'public', table: 'trips', filter: `user_id=eq.${state.user.id}` },
      (payload) => { debugLog('[realtime] trips event: ' + payload.eventType); scheduleRealtimeResync('trips'); })
    .on('postgres_changes', { event: '*', schema: 'public', table: 'noticeboard', filter: `user_id=eq.${state.user.id}` },
      (payload) => { debugLog('[realtime] noticeboard event: ' + payload.eventType); scheduleRealtimeResync('noticeboard'); })
    .on('postgres_changes', { event: '*', schema: 'public', table: 'profiles', filter: `id=eq.${state.user.id}` },
      (payload) => { debugLog('[realtime] profiles event: ' + payload.eventType); scheduleRealtimeResync('profile'); })
    .subscribe((status, err) => {
      debugLog('[realtime] channel status: ' + status + (err ? (' — ' + (err.message || err)) : ''));
    });

  // Friend requests sent to / by this person (friends.js) — on a SEPARATE
  // channel, so if the friendships table is ever missing or misconfigured it
  // can't take the boats/crew/trips/noticeboard/profile sync down with it.
  // Supabase can't filter DELETE events by column, so deletes (decline /
  // cancel / unfriend) arrive unfiltered and just trigger a cheap reload.
  _friendsChannel = getSupabaseClient()
    .channel(`friends-${state.user.id}`)
    .on('postgres_changes', { event: 'INSERT', schema: 'public', table: 'friendships', filter: `addressee_id=eq.${state.user.id}` },
      () => scheduleRealtimeResync('friends'))
    .on('postgres_changes', { event: 'UPDATE', schema: 'public', table: 'friendships', filter: `requester_id=eq.${state.user.id}` },
      () => scheduleRealtimeResync('friends'))
    .on('postgres_changes', { event: 'DELETE', schema: 'public', table: 'friendships' },
      () => scheduleRealtimeResync('friends'))
    .subscribe((status, err) => {
      // If this ever logs CHANNEL_ERROR, the friendships table probably isn't in the
      // supabase_realtime publication — run friends-realtime.sql. Friend requests
      // still arrive without it via the refresh safety net in friends.js, just slower.
      debugLog('[realtime] friends channel status: ' + status + (err ? (' — ' + (err.message || err)) : ''));
    });
}
function teardownRealtimeSync(){
  if(_friendsChannel){
    getSupabaseClient().removeChannel(_friendsChannel);
    _friendsChannel = null;
  }
  if(_realtimeChannel){
    getSupabaseClient().removeChannel(_realtimeChannel);
    _realtimeChannel = null;
    _realtimeUserId = null;
  }
  Object.values(_realtimeResyncTimers).forEach(clearTimeout);
}

// Debounced so a burst of changes (e.g. this same device's own push echoing
// back, or several boats added in quick succession on another device)
// triggers one re-pull instead of one per row event. Reuses the existing
// resolve*SyncOnSignIn functions as-is — same merge-by-updated_at logic,
// same cloud sync queue, same confirm-prompt behavior for a genuinely
// conflicting profile — this just adds a new trigger that calls them.
function scheduleRealtimeResync(kind){
  clearTimeout(_realtimeResyncTimers[kind]);
  _realtimeResyncTimers[kind] = setTimeout(() => {
    debugLog('[realtime] running resync: ' + kind);
    if(kind === 'boats') resolveBoatsSyncOnSignIn().then(()=>debugLog('[realtime] boats resync done')).catch(e => debugLog('[realtime] boats resync FAILED: ' + (e.message||e)));
    if(kind === 'crew') resolveCrewSyncOnSignIn().then(()=>debugLog('[realtime] crew resync done')).catch(e => debugLog('[realtime] crew resync FAILED: ' + (e.message||e)));
    if(kind === 'trips') resolveTripsSyncOnSignIn().then(()=>debugLog('[realtime] trips resync done')).catch(e => debugLog('[realtime] trips resync FAILED: ' + (e.message||e)));
    if(kind === 'noticeboard') resolveNoticeboardSyncOnSignIn().then(()=>debugLog('[realtime] noticeboard resync done')).catch(e => debugLog('[realtime] noticeboard resync FAILED: ' + (e.message||e)));
    if(kind === 'friends' && typeof loadFriendsData === 'function') loadFriendsData();
    if(kind === 'profile') resolveProfileSyncOnSignIn().then(()=>debugLog('[realtime] profile resync done')).catch(e => debugLog('[realtime] profile resync FAILED: ' + (e.message||e)));
  }, 600);
}

// Updates the Account card on the Settings screen. Safe to call any time —
// those elements are static markup that's always in the DOM (unlike most of
// the app's screens, Settings isn't re-rendered per visit), so this doesn't
// need to be hooked into nav().
function renderAccountUI(){
  const signedOutEl = document.getElementById('accountSignedOut');
  const signedInEl = document.getElementById('accountSignedIn');
  if(!signedOutEl || !signedInEl) return;

  if(state.user){
    signedOutEl.style.display = 'none';
    signedInEl.style.display = 'block';
    document.getElementById('accountEmailLine').textContent = state.user.email;
  } else {
    signedOutEl.style.display = 'block';
    signedInEl.style.display = 'none';
  }
}

/* ---------- the sign in / sign up sheet ---------- */
function openAuthSheet(mode){
  authMode = mode || 'signin';
  document.getElementById('authEmail').value = '';
  document.getElementById('authPassword').value = '';
  resetPasswordVisibility();
  hideAuthError();
  updateAuthSheetLabels();
  openSheet('sheetAuth');
}

// Lets someone check what they actually typed, since typos in a masked
// password field are otherwise invisible until the submit fails.
function togglePasswordVisibility(){
  const input = document.getElementById('authPassword');
  const btn = document.getElementById('authPasswordToggle');
  const showing = input.type === 'text';
  input.type = showing ? 'password' : 'text';
  btn.classList.toggle('is-active', !showing);
  btn.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
}
function resetPasswordVisibility(){
  document.getElementById('authPassword').type = 'password';
  const btn = document.getElementById('authPasswordToggle');
  btn.classList.remove('is-active');
  btn.setAttribute('aria-label', 'Show password');
}

function toggleAuthMode(){
  authMode = authMode === 'signin' ? 'signup' : 'signin';
  hideAuthError();
  updateAuthSheetLabels();
}

function updateAuthSheetLabels(){
  const isSignUp = authMode === 'signup';
  document.getElementById('authSheetTitle').textContent = isSignUp ? 'Create Account' : 'Sign In';
  document.getElementById('authSheetHint').textContent = isSignUp
    ? 'Create an account to sync your journeys across devices.'
    : 'Sign in to sync your journeys across devices.';
  document.getElementById('authSubmitBtn').textContent = isSignUp ? 'Create Account' : 'Sign In';
  document.getElementById('authToggleModeBtn').textContent = isSignUp
    ? 'Already have an account? Sign in'
    : "Don't have an account? Sign up";
}

function showAuthError(msg){
  const el = document.getElementById('authErrorMsg');
  el.textContent = msg;
  el.style.display = 'block';
}
function hideAuthError(){
  document.getElementById('authErrorMsg').style.display = 'none';
}

async function submitAuthForm(){
  const email = document.getElementById('authEmail').value.trim();
  const password = document.getElementById('authPassword').value;
  hideAuthError();

  if(!email || !password){
    showAuthError('Enter both an email and a password.');
    return;
  }
  if(password.length < 6){
    showAuthError('Password must be at least 6 characters.');
    return;
  }

  const btn = document.getElementById('authSubmitBtn');
  const originalLabel = btn.textContent;
  btn.disabled = true;
  btn.textContent = 'Please wait…';

  try{
    if(authMode === 'signup'){
      const { data, error } = await getSupabaseClient().auth.signUp({
        email, password,
        // Where the confirmation email's link sends people once Supabase has
        // verified them — the installed Android app via its deep link, or the
        // live web app. See authRedirectUrl() below.
        options: { emailRedirectTo: authRedirectUrl() }
      });
      if(error) throw error;
      closeSheets();
      if(data.session){
        // Email confirmation is off (or already satisfied) — signed in immediately.
        await resolveProfileSyncOnSignIn();
        await resolveBoatsSyncOnSignIn();
        await resolveCrewSyncOnSignIn();
        await resolveTripsSyncOnSignIn();
        await resolveNoticeboardSyncOnSignIn();
        showToast('Account created.');
      } else {
        // Normal case: Supabase emails a confirmation link and there's no
        // session yet — nothing to sync to until that link is clicked and
        // they sign in for the first time (handled in the signin branch below).
        showToast('Check your email to confirm your account.');
      }
    } else {
      const { error } = await getSupabaseClient().auth.signInWithPassword({ email, password });
      if(error) throw error;
      closeSheets();
      await resolveProfileSyncOnSignIn();
      await resolveBoatsSyncOnSignIn();
      await resolveCrewSyncOnSignIn();
      await resolveTripsSyncOnSignIn();
      await resolveNoticeboardSyncOnSignIn();
      showToast('Signed in.');
    }
  } catch(e){
    showAuthError(e.message || 'Something went wrong. Try again.');
  } finally {
    btn.disabled = false;
    btn.textContent = originalLabel;
  }
}

async function signOutUser(){
  if(!(await confirmDialog('signOut', {icon:'logout'}))) return;
  await getSupabaseClient().auth.signOut();
  showToast('Signed out.');
}

/* ---------- profile ↔ cloud resolution on sign-in ----------
   Runs once right after a successful sign-in (or a sign-up that logs
   straight in). Decides which direction data should move:
   - No cloud profile yet, or it matches this device exactly → push local up.
   - Cloud has a profile and this device is essentially blank (no name set)
     → pull it down with no prompt, since there's nothing local to lose.
   - Cloud has a profile AND this device already has its own local data that
     differs → ask before overwriting either side, rather than silently
     picking one. */
function resolveProfileSyncOnSignIn(){
  return withCloudSyncQueue(resolveProfileSyncOnSignInImpl);
}
// Plain JSON.stringify compares objects key-ORDER-sensitively, but Supabase's
// jsonb column re-sorts keys alphabetically on the way back out — so a
// profile that's genuinely identical to what was just pushed can still come
// back "different" by that comparison, endlessly re-triggering the "load
// from cloud?" prompt below every time this device's own push echoes back
// through the realtime listener (scheduleRealtimeResync). Sorting keys
// (recursively, so nested objects/arrays don't hit the same issue) before
// comparing fixes that without changing what actually gets read or written.
function stableStringify(value){
  if(value === null || typeof value !== 'object') return JSON.stringify(value);
  if(Array.isArray(value)) return '[' + value.map(stableStringify).join(',') + ']';
  return '{' + Object.keys(value).sort().map(k => JSON.stringify(k) + ':' + stableStringify(value[k])).join(',') + '}';
}
async function resolveProfileSyncOnSignInImpl(){
  if(!state.user) return;

  let cloudProfile = null;
  try{
    const { data, error } = await getSupabaseClient()
      .from('profiles')
      .select('profile_data')
      .eq('id', state.user.id)
      .maybeSingle();
    if(error) throw error;
    cloudProfile = data ? data.profile_data : null;
  }catch(e){
    console.error('profile cloud fetch failed', e);
  }

  const localHasData = !!(state.profile && state.profile.name);

  if(cloudProfile){
    const sameAsLocal = stableStringify(cloudProfile) === stableStringify(state.profile);
    // Identical on both sides — nothing to load, so do nothing and say nothing.
    // (This is the normal case on every app launch; it used to re-apply the same
    // profile and flash "Profile loaded from your account." each time.)
    if(sameAsLocal) return;
    if(!localHasData){
      await applyCloudProfile(cloudProfile);
      return;
    }
    const loadCloud = await confirmDialog('loadCloudProfile', {icon:'cloud'});
    if(loadCloud){
      await applyCloudProfile(cloudProfile);
      return;
    }
    // They chose to keep what's on this device — fall through and push it up instead.
  }

  await syncLocalProfileToCloudImpl();
}

// Applies a profile fetched from the cloud onto this device — saves it to
// local storage and refreshes the screens that show profile info, the same
// way restoreFromFile() does in storage.js for a manual backup restore.
async function applyCloudProfile(cloudProfile){
  state.profile = cloudProfile;
  await storeSet(KEYS.PROFILE, state.profile);
  await applyThemePreference();
  document.getElementById('homeName').textContent = state.profile.name || t('default.sailorName');
  refreshAvatars();
  showToast('Profile loaded from your account.');
}

/* ---------- boats ↔ cloud ----------
   Deliberately NOT the same shape as the old (removed) boats/crew sync: that
   version made "the cloud match this device exactly" on every sync, which
   meant a device with no local boats yet — e.g. one that hadn't pulled down
   for the first time — would delete every boat in the cloud. This version
   never infers a delete from something being merely absent locally or in
   the cloud. A boat is only ever removed from the cloud by an explicit
   local delete (deleteBoatFromCloud, called from deleteBoatForm). Everything
   else is push-this-one-boat (upsert) or pull-and-merge by timestamp —
   never a full-list replace in either direction. Crew is intentionally left
   out of this for now; adding it later should follow the same shape. */

// Push a single boat. Called after every local save (add or edit) — never
// batches the whole boats list, so this can't accidentally drop boats this
// device doesn't know about yet. Goes through the cloud sync queue (see
// above) so it can't race a concurrent pull.
function pushBoatToCloud(boat){
  return withCloudSyncQueue(() => pushBoatToCloudImpl(boat));
}
async function pushBoatToCloudImpl(boat){
  if(!state.user) return { ok:false };
  try{
    const { error } = await getSupabaseClient()
      .from('boats')
      .upsert({ id: boat.id, user_id: state.user.id, data: boat, updated_at: boat.updatedAt || new Date().toISOString() });
    if(error) throw error;
    return { ok:true };
  }catch(e){
    console.error('boat cloud push failed', e);
    return { ok:false, message: e.message || String(e) };
  }
}

// Marks a boat deleted — a soft-delete (tombstone) rather than a real SQL
// delete. This is the ONLY way a boat is ever removed from the cloud, and
// it's what lets other devices tell "the cloud has never heard of this id"
// (push it up) apart from "the cloud knows this was deleted" (remove it
// locally, never resurrect it) — see mergeBoats below. A real row delete
// couldn't carry that distinction, which is exactly why a boat deleted on
// one device used to come back after syncing another. Also goes through
// the cloud sync queue, same reason as pushBoatToCloud.
function deleteBoatFromCloud(boatId){
  return withCloudSyncQueue(() => deleteBoatFromCloudImpl(boatId));
}
async function deleteBoatFromCloudImpl(boatId){
  if(!state.user) return { ok:false };
  try{
    const { error } = await getSupabaseClient()
      .from('boats')
      .upsert({ id: boatId, user_id: state.user.id, data: {}, deleted_at: new Date().toISOString(), updated_at: new Date().toISOString() });
    if(error) throw error;
    return { ok:true };
  }catch(e){
    console.error('boat cloud delete failed', e);
    return { ok:false, message: e.message || String(e) };
  }
}

// Fire-and-forget wrappers, called right after routine local edits — same
// no-op-when-signed-out, log-don't-toast pattern as the profile ones above.
async function syncBoatIfSignedIn(boat){
  if(!state.user) return;
  debugLog('[sync] pushing boat ' + boat.id + ' (' + boat.name + ')...');
  const result = await pushBoatToCloud(boat);
  if(!result.ok){
    console.error('background boat sync failed', result.message);
    debugLog('[sync] boat push FAILED: ' + result.message);
  } else {
    debugLog('[sync] boat push OK: ' + boat.id);
  }
}
async function syncBoatDeleteIfSignedIn(boatId){
  if(!state.user) return;
  const result = await deleteBoatFromCloud(boatId);
  if(!result.ok) console.error('background boat delete sync failed', result.message);
}

// Merges local + cloud boat lists by id, newest updated_at wins. Never
// drops a boat just because it's missing from one side — a boat only in
// the cloud gets pulled in locally; a boat only on this device gets kept
// (and queued to push up); a boat in both keeps whichever copy is newer.
// This is what makes it safe to run on every sign-in and every manual sync,
// even from a device with an empty or stale local list.
//
// A cloud row with deleted_at set is a tombstone (see deleteBoatFromCloud)
// and is handled before any of that: it's dropped from the merged result
// unconditionally, and never queued to push back up — even if this device
// still has a local copy. Without this, "cloud doesn't have it" was
// indistinguishable from "cloud never heard of it", so a device that still
// had the boat locally would keep it AND push it right back to the cloud,
// undoing the delete every time it synced.
function mergeBoats(localBoats, cloudRows){
  const localById = new Map((localBoats||[]).map(b=>[b.id, b]));
  const cloudById = new Map((cloudRows||[]).map(r=>[r.id, r]));
  const allIds = new Set([...localById.keys(), ...cloudById.keys()]);

  const merged = [];
  const toPushUp = []; // boats whose local copy is newer (or local-only) and needs pushing

  for(const id of allIds){
    const local = localById.get(id);
    const cloud = cloudById.get(id);
    if(cloud && cloud.deleted_at){
      continue; // tombstoned — drop it locally, never resurrect it in the cloud
    }
    if(local && cloud){
      const localTime = local.updatedAt ? Date.parse(local.updatedAt) : 0;
      const cloudTime = cloud.updated_at ? Date.parse(cloud.updated_at) : 0;
      if(cloudTime > localTime){
        merged.push(cloud.data);
      } else {
        merged.push(local);
        if(localTime > cloudTime) toPushUp.push(local);
      }
    } else if(local && !cloud){
      merged.push(local);
      toPushUp.push(local);
    } else if(!local && cloud){
      merged.push(cloud.data);
    }
  }
  return { merged, toPushUp };
}

// Runs on sign-in (and manual sync): fetches the cloud's boats, merges with
// whatever's local, saves + renders the merged result, then pushes up any
// boats where the local copy won the merge. Safe to call from a device with
// zero local boats (nothing to push, everything just gets pulled in) or a
// device with real data the cloud hasn't seen yet (nothing gets lost). Goes
// through the cloud sync queue as a whole (see above) so it can't
// interleave with a push or delete that's still in flight — uses the
// unqueued *Impl push internally since this function already holds the
// queue's one slot.
function resolveBoatsSyncOnSignIn(){
  debugLog('[sync] resolveBoatsSyncOnSignIn() called — queuing...');
  return withCloudSyncQueue(resolveBoatsSyncOnSignInImpl);
}
async function resolveBoatsSyncOnSignInImpl(){
  debugLog('[sync] boats task DEQUEUED, starting');
  if(!state.user) return { ok:true };

  let cloudRows;
  try{
    debugLog('[sync] boats: sending fetch to Supabase...');
    const { data, error } = await getSupabaseClient()
      .from('boats')
      .select('id,data,updated_at,deleted_at')
      .eq('user_id', state.user.id);
    if(error) throw error;
    cloudRows = data || [];
  }catch(e){
    console.error('boats cloud fetch failed', e);
    debugLog('[sync] boats fetch THREW: ' + (e.message || String(e)));
    return { ok:false, message: 'fetch failed: ' + (e.message || String(e)) };
  }

  debugLog(`[sync] boats fetch OK — cloud rows: ${cloudRows.length} [${cloudRows.map(r=>r.id).join(',')}], local: ${(state.boats||[]).length} [${(state.boats||[]).map(b=>b.id).join(',')}]`);

  const { merged, toPushUp } = mergeBoats(state.boats, cloudRows);
  debugLog(`[sync] boats merged -> ${merged.length} [${merged.map(b=>b.id).join(',')}], pushing up ${toPushUp.length}`);
  if(toPushUp.length){
    const cloudById = new Map(cloudRows.map(r=>[r.id, r]));
    for(const b of toPushUp){
      const cr = cloudById.get(b.id);
      debugLog(`[sync] toPushUp: ${b.id} "${b.name}" local.updatedAt=${b.updatedAt} vs cloud.updated_at=${cr ? cr.updated_at : '(no cloud row)'}`);
    }
  }
  state.boats = merged;
  await storeSet(KEYS.BOATS, state.boats);
  renderBoats();

  for(const boat of toPushUp){
    debugLog(`[sync] pushing up boat ${boat.id} with updatedAt=${boat.updatedAt}...`);
    const result = await pushBoatToCloudImpl(boat);
    debugLog(`[sync] push result for ${boat.id}: ${result.ok ? 'OK' : ('FAILED — ' + result.message)}`);
    if(!result.ok) return { ok:false, message: result.message };
  }
  return { ok:true };
}

/* ---------- trips ↔ cloud ----------
   Same push-this-one-row-on-save/delete, pull-and-merge-on-sign-in shape as
   boats and crew above — with one structural difference worth flagging:
   boats/crew each live as a single array already in memory (state.boats /
   state.crew), but trips don't. Only the lightweight state.tripIndex is
   ever fully in memory; each trip's real data (GPS track, photos, notes)
   lives on disk under 'trip:'+id and is loaded on demand (see storage.js's
   backupToFile for the same load-every-trip pattern). So syncing trips
   means: load every local trip's full record first, merge those full
   records (not the index) against the cloud, write the merged full records
   back to storage, then rebuild tripIndex from whatever survived — rather
   than merging one in-memory array directly the way mergeBoats/mergeCrew
   do.
   NOTE: trip records can be considerably larger than boats/crew — a sail
   with a long GPS track and several embedded photos — so this moves more
   data per sync than boats/crew do. Same mechanism either way; just worth
   knowing if a big backlog of old sails syncs slower over a weak
   connection. */
async function pushTripToCloudImpl(trip){
  if(!state.user) return { ok:false };
  // Photos go to Supabase Storage first (photo-store.js), so the database row
  // only carries short references. If that fails (offline, or the storage
  // bucket isn't set up yet), the sail is still pushed the old way — it will
  // be retried on the next sync, so nothing is ever held back or lost.
  try{ await offloadTripPhotos(trip); }
  catch(e){ console.warn('photo upload failed — pushing this sail with photos inside for now', e); }
  try{
    // boatName is copied into the shared record so a friend viewing this sail
    // sees the boat's name (they don't have this person's Fleet). visibility
    // is its own column (not just inside `data`) because the database's
    // security rules read it to decide whether friends may see the sail.
    const boat = trip.boatId ? state.boats.find(b=>b.id===trip.boatId) : null;
    const data = { ...trip, boatName: trip.boatName || (boat ? boat.name : null) };
    const row = { id: trip.id, user_id: state.user.id, data, visibility: trip.visibility === 'friends' ? 'friends' : 'private',
      updated_at: trip.updatedAt || new Date().toISOString() };
    let { error } = await getSupabaseClient().from('trips').upsert(row);
    // Safety net: if friends-supabase.sql hasn't been run yet, the visibility
    // column doesn't exist — push without it rather than breaking trip sync.
    if(error && /visibility/i.test(error.message || '')){
      delete row.visibility;
      ({ error } = await getSupabaseClient().from('trips').upsert(row));
    }
    if(error) throw error;
    return { ok:true };
  }catch(e){
    console.error('trip cloud push failed', e);
    return { ok:false, message: e.message || String(e) };
  }
}
function pushTripToCloud(trip){
  return withCloudSyncQueue(() => pushTripToCloudImpl(trip));
}
// Fire-and-forget wrapper, called right after a trip is saved (see
// finalizeSaveTrip() in journey.js) — same no-op-when-signed-out,
// log-don't-toast pattern as the boats/crew ones above.
async function syncTripIfSignedIn(trip){
  if(!state.user) return;
  const result = await pushTripToCloud(trip);
  if(!result.ok) console.error('background trip sync failed', result.message);
}

// Soft-delete (tombstone) — same reasoning as deleteBoatFromCloudImpl
// above: a real SQL delete would be indistinguishable from "the cloud never
// heard of this trip", so a device that still has it locally would just
// push it right back and undo the delete on the next sync.
async function deleteTripFromCloudImpl(tripId){
  if(!state.user) return { ok:false };
  try{
    const { error } = await getSupabaseClient()
      .from('trips')
      .upsert({ id: tripId, user_id: state.user.id, data: {}, deleted_at: new Date().toISOString(), updated_at: new Date().toISOString() });
    if(error) throw error;
    return { ok:true };
  }catch(e){
    console.error('trip cloud delete failed', e);
    return { ok:false, message: e.message || String(e) };
  }
}
function deleteTripFromCloud(tripId){
  return withCloudSyncQueue(() => deleteTripFromCloudImpl(tripId));
}
// Fire-and-forget wrapper, called right after a trip is deleted (see
// deleteTripPrompt() in history-maps.js).
async function syncTripDeleteIfSignedIn(tripId){
  if(!state.user) return;
  const result = await deleteTripFromCloud(tripId);
  if(!result.ok) console.error('background trip delete sync failed', result.message);
}

// Identical shape to mergeBoats/mergeCrew — newest updated_at wins, a
// tombstoned cloud row is dropped unconditionally and never resurrected,
// and nothing is ever dropped just for being missing from one side.
function mergeTrips(localTrips, cloudRows){
  const localById = new Map((localTrips||[]).map(tr=>[tr.id, tr]));
  const cloudById = new Map((cloudRows||[]).map(r=>[r.id, r]));
  const allIds = new Set([...localById.keys(), ...cloudById.keys()]);

  const merged = [];
  const toPushUp = [];

  for(const id of allIds){
    const local = localById.get(id);
    const cloud = cloudById.get(id);
    if(cloud && cloud.deleted_at){
      continue; // tombstoned — drop it locally, never resurrect it in the cloud
    }
    if(local && cloud){
      const localTime = local.updatedAt ? Date.parse(local.updatedAt) : 0;
      const cloudTime = cloud.updated_at ? Date.parse(cloud.updated_at) : 0;
      if(cloudTime > localTime){
        merged.push(cloud.data);
      } else {
        merged.push(local);
        if(localTime > cloudTime) toPushUp.push(local);
      }
    } else if(local && !cloud){
      merged.push(local);
      toPushUp.push(local);
    } else if(!local && cloud){
      merged.push(cloud.data);
    }
  }
  return { merged, toPushUp };
}

// Builds a tripIndex summary entry from a full trip record — the exact same
// fields finalizeSaveTrip() computes in journey.js, kept in sync with that
// shape so a trip pulled down from the cloud looks identical in History to
// one saved locally on this device.
function tripIndexEntryFrom(trip){
  return {
    id: trip.id, title: trip.title, date: trip.date,
    elapsedSeconds: trip.elapsedSeconds, distanceNm: trip.distanceNm,
    avgSpeed: trip.avgSpeed, maxSpeed: trip.maxSpeed,
    coverPhoto: trip.coverPhoto, hasPhotos: (trip.photos||[]).length>0,
    boatId: trip.boatId, notes: trip.notes, place: trip.place,
    skipperId: trip.skipperId||null
  };
}

function resolveTripsSyncOnSignIn(){
  debugLog('[sync] resolveTripsSyncOnSignIn() called — queuing...');
  return withCloudSyncQueue(resolveTripsSyncOnSignInImpl);
}
async function resolveTripsSyncOnSignInImpl(){
  debugLog('[sync] trips task DEQUEUED, starting');
  if(!state.user) return { ok:true };

  // Load every trip this device actually has — not just the lightweight
  // index — since the merge needs each trip's real content to compare
  // updatedAt and to push up if this device's copy wins.
  const localTrips = [];
  for(const entry of state.tripIndex){
    const full = await storeGet('trip:'+entry.id);
    if(full) localTrips.push(full);
  }

  let cloudRows;
  try{
    debugLog('[sync] trips: sending fetch to Supabase...');
    const { data, error } = await getSupabaseClient()
      .from('trips')
      .select('id,data,updated_at,deleted_at')
      .eq('user_id', state.user.id);
    if(error) throw error;
    cloudRows = data || [];
  }catch(e){
    console.error('trips cloud fetch failed', e);
    debugLog('[sync] trips fetch THREW: ' + (e.message || String(e)));
    return { ok:false, message: 'fetch failed: ' + (e.message || String(e)) };
  }

  debugLog(`[sync] trips fetch OK — cloud rows: ${cloudRows.length} [${cloudRows.map(r=>r.id).join(',')}], local: ${localTrips.length} [${localTrips.map(tr=>tr.id).join(',')}]`);

  const { merged, toPushUp } = mergeTrips(localTrips, cloudRows);
  debugLog(`[sync] trips merged -> ${merged.length} [${merged.map(tr=>tr.id).join(',')}], pushing up ${toPushUp.length}`);

  // Write every surviving trip's full record back to storage, and drop the
  // full record for any local trip that didn't survive the merge (i.e. was
  // tombstoned elsewhere) — otherwise a deleted trip's data would keep
  // sitting on disk even after it disappears from the index.
  const mergedIds = new Set(merged.map(tr=>tr.id));
  for(const trip of merged){
    await storeSet('trip:'+trip.id, trip);
  }
  for(const entry of state.tripIndex){
    if(!mergedIds.has(entry.id)) await storeDelete('trip:'+entry.id);
  }

  state.tripIndex = merged.map(tripIndexEntryFrom);
  await storeSet(KEYS.INDEX, state.tripIndex);
  renderHistory();
  renderHomeStats();

  for(const trip of toPushUp){
    debugLog(`[sync] pushing up trip ${trip.id} with updatedAt=${trip.updatedAt}...`);
    const result = await pushTripToCloudImpl(trip);
    debugLog(`[sync] push result for ${trip.id}: ${result.ok ? 'OK' : ('FAILED — ' + result.message)}`);
    if(!result.ok) return { ok:false, message: result.message };
  }

  // One-off move of photos that are still stored inside older sails into
  // Supabase Storage. Each sail is pushed again once its photos are uploaded;
  // after that it has none left inside, so this finds nothing to do.
  let movedAny = false;
  for(const trip of merged){
    if(!tripHasInlineImages(trip) || _photoStorageUnavailable) continue;
    debugLog(`[sync] moving photos of trip ${trip.id} to storage...`);
    const result = await pushTripToCloudImpl(trip);
    if(!result.ok) console.warn('photo move push failed', trip.id, result.message);
    else movedAny = true;
  }
  if(movedAny){ renderHistory(); renderHomeStats(); }
  retryPendingPhotos();
  return { ok:true };
}

/* ---------- crew ↔ cloud ----------
   Exactly the same shape as boats above: push-this-one-row on edit, explicit
   single-row delete, merge-by-id-and-updated_at on sign-in/boot/manual sync.
   Never a full-list replace in either direction — see the boats comment
   above for why. */

// Push a single crew member. Called after every local save (add or edit).
// Goes through the cloud sync queue, same reason as pushBoatToCloud.
function pushCrewToCloud(crewMember){
  return withCloudSyncQueue(() => pushCrewToCloudImpl(crewMember));
}
async function pushCrewToCloudImpl(crewMember){
  if(!state.user) return { ok:false };
  try{
    const { error } = await getSupabaseClient()
      .from('crew')
      .upsert({ id: crewMember.id, user_id: state.user.id, data: crewMember, updated_at: crewMember.updatedAt || new Date().toISOString() });
    if(error) throw error;
    return { ok:true };
  }catch(e){
    console.error('crew cloud push failed', e);
    return { ok:false, message: e.message || String(e) };
  }
}

// Marks a crew member deleted — a soft-delete (tombstone), same reasoning
// as deleteBoatFromCloud above. The ONLY way a crew member is ever removed
// from the cloud. Also goes through the cloud sync queue.
function deleteCrewFromCloud(crewId){
  return withCloudSyncQueue(() => deleteCrewFromCloudImpl(crewId));
}
async function deleteCrewFromCloudImpl(crewId){
  if(!state.user) return { ok:false };
  try{
    const { error } = await getSupabaseClient()
      .from('crew')
      .upsert({ id: crewId, user_id: state.user.id, data: {}, deleted_at: new Date().toISOString(), updated_at: new Date().toISOString() });
    if(error) throw error;
    return { ok:true };
  }catch(e){
    console.error('crew cloud delete failed', e);
    return { ok:false, message: e.message || String(e) };
  }
}

// Fire-and-forget wrappers, called right after routine local edits.
async function syncCrewIfSignedIn(crewMember){
  if(!state.user) return;
  const result = await pushCrewToCloud(crewMember);
  if(!result.ok) console.error('background crew sync failed', result.message);
}
async function syncCrewDeleteIfSignedIn(crewId){
  if(!state.user) return;
  const result = await deleteCrewFromCloud(crewId);
  if(!result.ok) console.error('background crew delete sync failed', result.message);
}

// Same merge shape as mergeBoats — newest updated_at wins, nothing is ever
// dropped just for being missing on one side, and a deleted_at tombstone is
// honored unconditionally (see mergeBoats for why).
function mergeCrew(localCrew, cloudRows){
  const localById = new Map((localCrew||[]).map(c=>[c.id, c]));
  const cloudById = new Map((cloudRows||[]).map(r=>[r.id, r]));
  const allIds = new Set([...localById.keys(), ...cloudById.keys()]);

  const merged = [];
  const toPushUp = [];

  for(const id of allIds){
    const local = localById.get(id);
    const cloud = cloudById.get(id);
    if(cloud && cloud.deleted_at){
      continue; // tombstoned — drop it locally, never resurrect it in the cloud
    }
    if(local && cloud){
      const localTime = local.updatedAt ? Date.parse(local.updatedAt) : 0;
      const cloudTime = cloud.updated_at ? Date.parse(cloud.updated_at) : 0;
      if(cloudTime > localTime){
        merged.push(cloud.data);
      } else {
        merged.push(local);
        if(localTime > cloudTime) toPushUp.push(local);
      }
    } else if(local && !cloud){
      merged.push(local);
      toPushUp.push(local);
    } else if(!local && cloud){
      merged.push(cloud.data);
    }
  }
  return { merged, toPushUp };
}

// Runs on sign-in, boot-time session restore, and manual sync — same
// safety properties as resolveBoatsSyncOnSignIn, including going through
// the cloud sync queue as a whole and using the unqueued *Impl push
// internally.
function resolveCrewSyncOnSignIn(){
  return withCloudSyncQueue(resolveCrewSyncOnSignInImpl);
}
async function resolveCrewSyncOnSignInImpl(){
  if(!state.user) return { ok:true };

  let cloudRows;
  try{
    const { data, error } = await getSupabaseClient()
      .from('crew')
      .select('id,data,updated_at,deleted_at')
      .eq('user_id', state.user.id);
    if(error) throw error;
    cloudRows = data || [];
  }catch(e){
    console.error('crew cloud fetch failed', e);
    return { ok:false, message: 'fetch failed: ' + (e.message || String(e)) };
  }

  const { merged, toPushUp } = mergeCrew(state.crew, cloudRows);
  state.crew = merged;
  await storeSet(KEYS.CREW, state.crew);
  renderCrew();

  for(const crewMember of toPushUp){
    const result = await pushCrewToCloudImpl(crewMember);
    if(!result.ok) return { ok:false, message: result.message };
  }
  return { ok:true };
}

/* ---------- profile → cloud sync ----------
   One-way for now: pushes this device's local profile up to the profiles
   table, overwriting whatever was there. Runs after every successful sign-in
   (not on session-restore at app boot — only on an actual sign-in action),
   so it's always this device's copy that wins. There's no pull-down yet
   (a second device won't fetch this automatically) — that's the next piece
   to build once this is confirmed working.
   Uses upsert rather than update: an account whose profiles row doesn't
   exist yet (e.g. it predates the profiles table, or the create-on-signup
   trigger didn't fire for some other reason) would silently no-op under
   update — upsert creates the row if it's missing. Returns true/false so
   callers can tell the person whether it actually worked. */
function syncLocalProfileToCloud(){
  return withCloudSyncQueue(syncLocalProfileToCloudImpl);
}
async function syncLocalProfileToCloudImpl(){
  if(!state.user) return { ok:false };
  try{
    const { error } = await getSupabaseClient()
      .from('profiles')
      .upsert({ id: state.user.id, display_name: state.profile.name || null, profile_data: state.profile });
    if(error){ console.error('profile cloud sync failed', error); return { ok:false, message: error.message }; }
    return { ok:true };
  }catch(e){
    console.error('profile cloud sync failed', e);
    return { ok:false, message: e.message || String(e) };
  }
}

// Fire-and-forget cloud push, called after any LOCAL edit to the profile
// (name, theme, units, etc.) so changes made after the initial sign-in sync
// also reach other devices — previously only the one-time sign-in
// resolution and the manual "Sync" button ever pushed to the cloud, so any
// edit made afterward silently stayed on that device only. No-ops (and no
// toast) when signed out; failures are logged, not surfaced, since these
// run silently after routine local saves.
async function syncProfileIfSignedIn(){
  if(!state.user) return;
  const result = await syncLocalProfileToCloud();
  if(!result.ok) console.error('background profile sync failed', result.message);
  // Keep the public friends card (name + small photo) in step — see friends.js.
  if(typeof syncPublicProfileIfSignedIn === 'function') syncPublicProfileIfSignedIn(true);
}

// Manual trigger from the Settings Account card. Reuses the same safe
// resolve logic as sign-in (pull down if the cloud has a profile this
// device lacks, ask before overwriting if both sides differ) rather than
// blindly pushing.
async function manualSyncProfile(){
  const btn = document.getElementById('syncProfileBtn');
  const originalLabel = btn.textContent;
  btn.disabled = true;
  btn.textContent = 'Syncing…';
  try{
    await resolveProfileSyncOnSignIn();
    const boatsResult = await resolveBoatsSyncOnSignIn();
    if(!boatsResult.ok){
      showToast('Sync failed: ' + boatsResult.message);
      return;
    }
    const crewResult = await resolveCrewSyncOnSignIn();
    if(!crewResult.ok){
      showToast('Sync failed: ' + crewResult.message);
      return;
    }
    const tripsResult = await resolveTripsSyncOnSignIn();
    if(!tripsResult.ok){
      showToast('Sync failed: ' + tripsResult.message);
      return;
    }
    const noticeboardResult = await resolveNoticeboardSyncOnSignIn();
    if(noticeboardResult.ok){
      showToast('Synced to cloud.');
    } else {
      showToast('Sync failed: ' + noticeboardResult.message);
    }
  }catch(e){
    console.error('manual sync failed', e);
    showToast("Sync failed — check you're online.");
  }finally{
    btn.disabled = false;
    btn.textContent = originalLabel;
  }
}

/* ---------- noticeboard ↔ cloud ----------
   Same shape as boats and crew above: one row per plan in the Supabase table
   `noticeboard` (id, user_id, data jsonb, updated_at, deleted_at), pushed after every
   local save, tombstoned (deleted_at) rather than really deleted, and pulled + merged
   newest-updated_at-wins on sign-in, boot, "Sync Now" and whenever Realtime reports a
   change on the table. Everything goes through the same cloud sync queue.
   Needs the table + RLS policies + Realtime switched on — see noticeboard-supabase.sql —
   and, for sharing plans with friends, the visibility column + friends policy from
   noticeboard-friends.sql.
   Until that has been run, these calls just fail quietly (logged) and the Noticeboard
   keeps working locally exactly as before. */
function pushNoticeboardToCloud(entry){
  return withCloudSyncQueue(() => pushNoticeboardToCloudImpl(entry));
}
async function pushNoticeboardToCloudImpl(entry){
  if(!state.user) return { ok:false };
  try{
    // Same idea as trips: boatName is copied into the shared record so a friend sees the
    // boat's name (they don't have this person's Fleet), and visibility is its own column
    // because the database's security rules read it to decide whether friends may see it.
    const boat = entry.boatId ? state.boats.find(b=>b.id===entry.boatId) : null;
    const data = { ...entry, boatName: boat ? boat.name : (entry.boatName || null) };
    const row = { id: entry.id, user_id: state.user.id, data, visibility: entry.visibility === 'friends' ? 'friends' : 'private',
      updated_at: entry.updatedAt || new Date().toISOString() };
    let { error } = await getSupabaseClient().from('noticeboard').upsert(row);
    // Safety net: if noticeboard-friends.sql hasn't been run yet, the visibility column
    // doesn't exist — push without it rather than breaking Noticeboard sync.
    if(error && /visibility/i.test(error.message || '')){
      delete row.visibility;
      ({ error } = await getSupabaseClient().from('noticeboard').upsert(row));
    }
    if(error) throw error;
    return { ok:true };
  }catch(e){
    console.error('noticeboard cloud push failed', e);
    return { ok:false, message: e.message || String(e) };
  }
}
// Soft-delete (tombstone) — the only way a plan is ever removed from the cloud, so other
// devices can tell "deleted" apart from "never heard of it" (see mergeNoticeboard).
function deleteNoticeboardFromCloud(entryId){
  return withCloudSyncQueue(() => deleteNoticeboardFromCloudImpl(entryId));
}
async function deleteNoticeboardFromCloudImpl(entryId){
  if(!state.user) return { ok:false };
  try{
    const now = new Date().toISOString();
    const { error } = await getSupabaseClient()
      .from('noticeboard')
      .upsert({ id: entryId, user_id: state.user.id, data: {}, deleted_at: now, updated_at: now });
    if(error) throw error;
    return { ok:true };
  }catch(e){
    console.error('noticeboard cloud delete failed', e);
    return { ok:false, message: e.message || String(e) };
  }
}
// Fire-and-forget wrappers called right after routine local edits (no-op when signed out).
async function syncNoticeboardIfSignedIn(entry){
  if(!state.user) return;
  const result = await pushNoticeboardToCloud(entry);
  if(!result.ok) console.error('background noticeboard sync failed', result.message);
}
async function syncNoticeboardDeleteIfSignedIn(entryId){
  if(!state.user) return;
  const result = await deleteNoticeboardFromCloud(entryId);
  if(!result.ok) console.error('background noticeboard delete sync failed', result.message);
}
// Merge by id, newest updated_at wins; a plan only on one side is kept (and pushed up if it
// is the local one); a tombstoned cloud row removes the plan locally and is never resurrected.
function mergeNoticeboard(localEntries, cloudRows){
  const localById = new Map((localEntries||[]).map(e=>[e.id, e]));
  const cloudById = new Map((cloudRows||[]).map(r=>[r.id, r]));
  const allIds = new Set([...localById.keys(), ...cloudById.keys()]);
  const merged = [], toPushUp = [];
  for(const id of allIds){
    const local = localById.get(id), cloud = cloudById.get(id);
    if(cloud && cloud.deleted_at) continue;
    if(local && cloud){
      const localTime = local.updatedAt ? Date.parse(local.updatedAt) : 0;
      const cloudTime = cloud.updated_at ? Date.parse(cloud.updated_at) : 0;
      if(cloudTime > localTime){ merged.push(cloud.data); }
      else { merged.push(local); if(localTime > cloudTime) toPushUp.push(local); }
    } else if(local && !cloud){
      merged.push(local); toPushUp.push(local);
    } else if(!local && cloud){
      merged.push(cloud.data);
    }
  }
  return { merged, toPushUp };
}
function resolveNoticeboardSyncOnSignIn(){
  return withCloudSyncQueue(resolveNoticeboardSyncOnSignInImpl);
}
async function resolveNoticeboardSyncOnSignInImpl(){
  if(!state.user) return { ok:true };
  let cloudRows;
  try{
    const { data, error } = await getSupabaseClient()
      .from('noticeboard')
      .select('id,data,updated_at,deleted_at')
      .eq('user_id', state.user.id);
    if(error) throw error;
    cloudRows = data || [];
  }catch(e){
    console.error('noticeboard cloud fetch failed', e);
    return { ok:false, message: 'noticeboard fetch failed: ' + (e.message || String(e)) };
  }
  const { merged, toPushUp } = mergeNoticeboard(state.noticeboard, cloudRows);
  state.noticeboard = merged;
  await storeSet(KEYS.NOTICEBOARD, state.noticeboard);
  renderNoticeboard();
  syncNoticeboardReminders(); // plans added/changed/deleted on another device -> update this phone's reminders
  for(const entry of toPushUp){
    const result = await pushNoticeboardToCloudImpl(entry);
    if(!result.ok) return { ok:false, message: result.message };
  }
  return { ok:true };
}
