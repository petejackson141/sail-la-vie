// ===== state-core.js =====
// Global app state object, boot(), nav()/screen switching, action sheets, wake lock, photo resize + crop/adjust tool
// Extracted from the original single-file app.js, lines 1470-1776, in original order.

// Bumped automatically on every change Claude hands over — format is
// DD.MM.YYYY.HHMM (the moment the fix was produced, UTC). Shown in Settings
// so you can ask a tester "what version does yours say?" instead of
// guessing whether they're on the latest code — this exists BECAUSE of the
// caching mess a few pushes back, where nobody could tell whether an old
// build was still stuck on someone's phone. You shouldn't need to touch
// this yourself.
const APP_VERSION = '26.09.2026.1605';

/* ============================================================
   CONFIRM DIALOG (shared across all screens)
   The ONE pop-up style for every "are you sure?" question in the app, so they
   all look the same and follow the current theme (light/dark and the nautical
   themes) through the app's own colour variables and button classes.

   Normal use — by name, with all wording in i18n.js (dlg.<name>.title/body/ok):
     if(await confirmDialog('removeBoat', {danger:true, icon:'trash'})) { ... }
   Low-level use (e.g. a message built on the fly):
     if(await showConfirm(bodyText, {title, okLabel, cancelLabel, danger, icon})) { ... }

   danger:true  -> red icon + red confirm button (anything that deletes/discards)
   icon         -> one of the names in CONFIRM_ICONS below
   Resolves true for the confirm button, false for Cancel or tapping outside.
   ============================================================ */
const CONFIRM_ICONS = {
  trash:   '<path d="M4 7h16"/><path d="M10 11v6M14 11v6"/><path d="M5 7l1 12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2l1-12"/><path d="M9 7V4a1 1 0 0 1 1-1h4a1 1 0 0 1 1 1v3"/>',
  logout:  '<path d="M14 8V6a2 2 0 0 0-2-2H5a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h7a2 2 0 0 0 2-2v-2"/><path d="M9 12h12"/><path d="M18 9l3 3-3 3"/>',
  cloud:   '<path d="M7 18a4.5 4.5 0 0 1-.5-9A6 6 0 0 1 18 9a4 4 0 0 1 0 9"/><path d="M12 12v8"/><path d="M9 17l3 3 3-3"/>',
  flag:    '<path d="M5 21V4"/><path d="M5 4h12l-2.5 4L17 12H5"/>',
  check:   '<path d="M5 12.5l4.5 4.5L19 7.5"/>',
  pin:     '<path d="M12 21s-7-6.2-7-11.5a7 7 0 0 1 14 0C19 14.8 12 21 12 21z"/><circle cx="12" cy="9.5" r="2.5"/>',
  restore: '<path d="M3.5 12a8.5 8.5 0 1 0 2.6-6.1"/><path d="M3.5 4v5h5"/>',
  userMinus:'<circle cx="9" cy="8" r="4"/><path d="M2.5 20a6.5 6.5 0 0 1 13 0"/><path d="M16 11h6"/>',
  alert:   '<path d="M12 9v4"/><path d="M12 17h.01"/><path d="M10.3 3.9L2.4 18a2 2 0 0 0 1.7 3h15.8a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0z"/>',
  question:'<circle cx="12" cy="12" r="9"/><path d="M9.5 9.5a2.5 2.5 0 1 1 3.5 2.3c-.6.3-1 .9-1 1.6v.6"/><path d="M12 17h.01"/>',
};
function showConfirm(message, opts={}){
  const danger = !!opts.danger;
  // No separate title given: show the message itself as the (bold) question.
  const title = opts.title || message || '';
  if(!opts.title) message = '';
  const okLabel = opts.okLabel || t('dlg.confirm');
  const cancelLabel = opts.cancelLabel || t('dlg.cancel');
  const icon = CONFIRM_ICONS[opts.icon] || (danger ? CONFIRM_ICONS.alert : CONFIRM_ICONS.question);

  if(!document.getElementById('customConfirmStyles')){
    const style = document.createElement('style');
    style.id = 'customConfirmStyles';
    style.textContent = `
      .cc-overlay{position:fixed;inset:0;z-index:9990;padding:24px;
        background:rgba(10,22,34,.5);backdrop-filter:blur(3px);-webkit-backdrop-filter:blur(3px);
        display:flex;align-items:center;justify-content:center;opacity:0;transition:opacity .18s ease;}
      .cc-overlay.show{opacity:1;}
      .cc-card{width:100%;max-width:340px;padding:22px 20px 18px;
        background:var(--surface-ivory, var(--bg-elevated));color:var(--ink);
        border:1px solid var(--border);border-radius:var(--radius-lg);box-shadow:var(--shadow);
        transform:scale(.94) translateY(8px);transition:transform .2s ease;}
      .cc-overlay.show .cc-card{transform:none;}
      .cc-icon{width:46px;height:46px;border-radius:50%;margin-bottom:14px;
        display:flex;align-items:center;justify-content:center;
        background:color-mix(in srgb, var(--teal) 14%, transparent);color:var(--teal);}
      .cc-icon.danger{background:color-mix(in srgb, var(--coral) 15%, transparent);color:var(--coral-deep);}
      html[data-theme="dark"] .cc-icon.danger{color:var(--coral);}
      .cc-icon svg{width:23px;height:23px;fill:none;stroke:currentColor;stroke-width:1.9;stroke-linecap:round;stroke-linejoin:round;}
      .cc-title{margin:0 0 6px;font-family:var(--font-display);font-size:19px;font-weight:600;line-height:1.3;color:var(--ink);}
      .cc-msg{margin:0 0 20px;font-size:14.5px;line-height:1.5;color:var(--ink-muted);}
      .cc-actions{display:flex;gap:10px;}
      .cc-actions .btn{padding:13px 12px;font-size:15px;flex:1;min-width:0;box-shadow:none;}
    `;
    document.head.appendChild(style);
  }

  return new Promise(resolve=>{
    const overlay = document.createElement('div');
    overlay.className = 'cc-overlay';
    overlay.innerHTML = `
      <div class="cc-card" role="alertdialog" aria-modal="true">
        <div class="cc-icon ${danger?'danger':''}"><svg viewBox="0 0 24 24" aria-hidden="true">${icon}</svg></div>
        <p class="cc-title"></p>
        <p class="cc-msg"></p>
        <div class="cc-actions">
          <button class="btn btn-outline" data-act="cancel"></button>
          <button class="btn ${danger?'btn-danger':'btn-primary'}" data-act="ok"></button>
        </div>
      </div>`;
    overlay.querySelector('.cc-title').textContent = title;
    overlay.querySelector('.cc-msg').textContent = message;
    if(!message){ overlay.querySelector('.cc-msg').remove(); overlay.querySelector('.cc-title').style.marginBottom = '20px'; }
    overlay.querySelector('[data-act="cancel"]').textContent = cancelLabel;
    overlay.querySelector('[data-act="ok"]').textContent = okLabel;

    function close(result){
      overlay.classList.remove('show');
      setTimeout(()=>overlay.remove(), 200);
      resolve(result);
    }
    overlay.querySelector('[data-act="cancel"]').onclick = ()=>close(false);
    overlay.querySelector('[data-act="ok"]').onclick = ()=>close(true);
    overlay.addEventListener('click', e=>{ if(e.target===overlay) close(false); });

    document.body.appendChild(overlay);
    requestAnimationFrame(()=>overlay.classList.add('show'));
  });
}
// Named dialogs: title, explanation and button wording all come from i18n.js
// (dlg.<name>.title / .body / .ok), so every language gets the full text.
// vars fills placeholders like {name}; any showConfirm option can be passed too.
function confirmDialog(name, opts={}){
  const { vars, ...rest } = opts;
  const cancelKey = 'dlg.'+name+'.cancel';
  const cancel = t(cancelKey);
  return showConfirm(t('dlg.'+name+'.body', vars), {
    title: t('dlg.'+name+'.title', vars),
    okLabel: t('dlg.'+name+'.ok', vars),
    cancelLabel: cancel !== cancelKey ? cancel : undefined,
    ...rest,
  });
}

let state = {
  tripIndex: [],   // lightweight list for History screen — NOT the full trip records (those are stored separately as 'trip:<id>')
  boats: [],
  crew: [],
  noticeboard: [],       // planned future sails, written on the Noticeboard screen — see noticeboard.js
  profile: { name:'', role:'', license:'', phone:'', email:'', social:'', bio:'', avatar:'', cover:'', theme:'light', unitSystem:'nautical', language:'en' },
  // Per-screen list/grid display choice for the Fleet and Crew screens — see
  // setListView()/renderBoats()/renderCrew(). Persisted so the choice sticks
  // between app launches, same as everything else in `state`.
  viewPrefs: { boats:'list', crew:'list' },
};

// The logged-in Supabase account, if any: null when signed out, or
// { id, email } when signed in. Set by auth.js (see initAuth()/applySession()
// there) — nothing here writes to it directly. This is separate from
// state.profile, which is the local on-device profile that's existed all along.
state.user = null;

let currentTrip = null;   // the ONE journey/manual-entry/edit in progress right now; null when nothing's active — check this first if the active screen misbehaves
let watchId = null;       // navigator.geolocation.watchPosition() handle, so stopGPS() can cancel it
let nativeGpsActive = false; // true while a native recorder (SailTracker, or the Transistorsoft fallback) is running instead of watchPosition — see NATIVE_TRACKER in journey.js
let timerId = null;       // setInterval() handle for the elapsed-time ticker
let startedAt = null;     // Date.now() when the current live journey began, used to compute elapsed time
let lastFixTime = null;   // Date.now() of the last GPS fix we RECEIVED (accepted or not) — drives the staleness watchdog in journey.js
let gpsWatchdogInterval = null; // setInterval() handle that checks lastFixTime and flags/restarts a silently-dead GPS watch
let bestRejectedFix = null;     // best (lowest-accuracy-radius) fix we've rejected for being too imprecise, kept as a fallback so chronically weak signal doesn't mean zero points get recorded
let pendingJumpCandidate = null; // last fix rejected for implying an implausible (60+kt) jump — held so a SECOND agreeing fix can confirm it's a real relocation rather than a one-off glitch (see acceptFix() in journey.js)
let wakeLock = null;      // Screen Wake Lock, held while a live journey is running to reduce the chance
                           // of the OS suspending/killing the tab when the screen would otherwise sleep

// Persists currentTrip + startedAt to storage so a killed/reloaded tab can pick the
// journey back up instead of silently losing it. Called after every GPS fix, every
// tick of the timer, and on any state-changing action while a trip is active.
// Cheap (small JSON) so it's safe to call this often; storeSet is fire-and-forget here.
function saveActiveTripCheckpoint(){
  if(!currentTrip) return;
  // Returns the storeSet promise (rather than fire-and-forget internally) so the one
  // call site that needs a guarantee — beginJourney(), right after Cast Off — can
  // await it. Every other call site just calls this without awaiting, same as before.
  return storeSet(KEYS.ACTIVE_TRIP, { trip: currentTrip, startedAt });
}
function clearActiveTripCheckpoint(){
  storeDelete(KEYS.ACTIVE_TRIP);
}
async function requestWakeLock(){
  try{
    if('wakeLock' in navigator){ wakeLock = await navigator.wakeLock.request('screen'); }
  }catch(e){ /* not fatal — recovery-on-reload is the real safety net */ }
}
function releaseWakeLock(){
  if(wakeLock){ wakeLock.release().catch(()=>{}); wakeLock = null; }
}

function uid(){ return Date.now().toString(36)+Math.random().toString(36).slice(2,7); }

/* ---------- boot: runs once on page load, loads everything from storage,
   then reveals the app (hides the loading spinner) ---------- */
async function boot(){
  await initStorage();

  const [idx, boats, crew, profile, viewPrefs, noticeboard] = await Promise.all([
    storeGet(KEYS.INDEX), storeGet(KEYS.BOATS), storeGet(KEYS.CREW), storeGet(KEYS.PROFILE), storeGet(KEYS.VIEW_PREFS), storeGet(KEYS.NOTICEBOARD)
  ]);
  state.tripIndex = idx || [];
  state.boats = boats || [];
  state.crew = crew || [];
  state.noticeboard = noticeboard || [];
  // The Noticeboard was called "Diary" in the build just before this one — carry any plans
  // saved under the old storage key over to the new one (one-off, then the old key is removed).
  if(!noticeboard){
    const legacy = await storeGet('diary');
    if(legacy && legacy.length){ state.noticeboard = legacy; await storeSet(KEYS.NOTICEBOARD, legacy); }
    if(legacy) await storeDelete('diary');
  }
  state.profile = profile || state.profile;
  state.viewPrefs = viewPrefs || state.viewPrefs;

  // Only now that local boats/profile are loaded is it safe to check for an
  // existing session and (if signed in) silently pull from the cloud — see
  // initAuth(). Doing this any earlier would race: a cloud pull landing
  // before local storage finished loading would just get overwritten by the
  // lines above. Not awaited, same as before, so a slow/offline network
  // doesn't delay the app opening — renderAccountUI() updates Settings
  // whenever it resolves, even after the rest of boot() finishes.
  const authReady = initAuth().catch(e => console.error('initAuth failed', e));
  currentLang = 'en'; // language picker hidden for now — es/pt/he dictionaries kept intact for later
  applyStaticTranslations();

  await applyThemePreference();
  renderUnitsSettingUI();

  refreshAvatars();
  document.getElementById('homeName').textContent = state.profile.name || t('default.sailorName');
  document.getElementById('appVersionLine').textContent = t('settings.version', {version: APP_VERSION});
  greet();

  // Baseline history entry for the Android back-button integration below —
  // gives popstate a known "home" state to fall back to.
  history.replaceState({type:'screen', name:'home'}, '', location.href);
  initHardwareBackButton();

  // Wait (briefly) for the session check so the sign-in gate can be decided before Home is shown:
  // a signed-in person never sees it flash up. Capped at 2.5s so a slow network can't hold the app
  // back — if the check finishes later and finds a session, applySession() hides the gate again.
  await Promise.race([authReady, new Promise(r=>setTimeout(r, 2500))]);
  showWelcomeGateIfSignedOut();

  const resumed = await resumeActiveTripIfAny();
  if(!resumed) nav('home', true); // already home — skip pushing a duplicate entry
  renderHomeStats();
  initNoticeboardNotificationTap();
  syncNoticeboardReminders(); // re-apply this phone's Noticeboard reminders (no-op outside the native app)
}
function greet(){
  const h = new Date().getHours();
  document.getElementById('homeGreeting').textContent = h<12 ? t('greet.morning') : h<18 ? t('greet.afternoon') : t('greet.evening');
}
function refreshAvatars(){
  const a = state.profile.avatar || placeholderAvatar();
  document.getElementById('homeAvatar').src = a;
  document.getElementById('profileAvatarImg').src = a;
}
function placeholderAvatar(){
  return 'data:image/svg+xml;utf8,' + encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="80" height="80"><rect width="80" height="80" fill="#16324F"/><circle cx="40" cy="32" r="14" fill="#BFE0EA"/><path d="M14 70c0-16 12-26 26-26s26 10 26 26" fill="#BFE0EA"/></svg>`);
}

/* ---------- navigation: nav(name) is the app's entire "router" — it just
   shows the matching .screen div and hides the rest. No URL involved, but it
   DOES push a browser history entry per screen switch (see the back-button
   block below) so Android's hardware/gesture back steps through the app
   instead of exiting it straight away.
   fromPopState=true means "the back button already got us here, just update
   the UI" — skips pushing a duplicate history entry. ---------- */
function nav(name, fromPopState){
  const prevActiveEl = document.querySelector('.screen.active');
  const prevName = prevActiveEl ? prevActiveEl.id.replace('screen-','') : null;
  document.querySelectorAll('.screen').forEach(s=>s.classList.remove('active'));
  document.getElementById('screen-'+name).classList.add('active');
  document.querySelectorAll('.navitem').forEach(n=>n.classList.toggle('active', n.dataset.tab===name));
  window.scrollTo(0,0);
  if(!fromPopState && name!==prevName){
    history.pushState({type:'screen', name}, '', location.href);
  }
  if(name==='history') renderHistory();
  if(name==='boats') renderBoats();
  if(name==='crew') renderCrew();
  if(name==='profile') renderProfileScreen();
  if(name==='resume') renderResume();
  if(name==='gallery') renderGallery();
  if(name==='noticeboard') renderNoticeboard();
  if(name==='active' && liveLeafletMap){
    // Leaflet sizes itself incorrectly if it was updated while its container was
    // hidden behind another screen (backgrounded journey) — fix it up now that
    // it's visible again.
    setTimeout(()=>{ liveLeafletMap.invalidateSize(); if(currentTrip && currentTrip.path.length) updateLiveLeafletTrack(currentTrip.path); }, 50);
  }
  updateRecordingBanner(name);
}
// Shows/hides the "🔴 Recording" banner above the bottom nav whenever a journey,
// manual entry, or edit is in progress and you've navigated away from the active
// screen (backgrounded, not stopped). Text and pulsing dot vary by what kind of
// entry is in flight.
function updateRecordingBanner(currentScreen){
  const banner = document.getElementById('recordingBanner');
  const show = !!currentTrip && currentScreen!=='active';
  banner.classList.toggle('show', show);
  banner.querySelector('.dot').style.display = (show && !currentTrip.isManual) ? 'block' : 'none';
  document.getElementById('recordingBannerTime').style.display = (show && !currentTrip.isManual) ? 'block' : 'none';
  if(show){
    const boat = state.boats.find(b=>b.id===currentTrip.boatId);
    if(currentTrip.isEditing){
      document.getElementById('recordingBannerText').textContent = t('banner.unsavedEdits');
    } else if(currentTrip.isManual){
      document.getElementById('recordingBannerText').textContent = t('banner.unsavedPastSail');
    } else {
      document.getElementById('recordingBannerText').textContent = boat ? t('banner.recordingBoat', {boat: boat.name}) : t('banner.recordingJourney');
    }
  }
}
/* ---------- Fleet/Crew list ↔ grid toggle ----------
   kind is 'boats' or 'crew'. Flips state.viewPrefs[kind] between 'list' and
   'grid', persists it (so it's remembered next launch), updates the toggle
   button's own icon/pressed state, and re-renders that screen's list.
   renderBoats()/renderCrew() (boats-crew.js) read state.viewPrefs[kind] to
   decide which markup (.row-card rows vs .grid-card tiles) to build. */
function toggleListView(kind){
  state.viewPrefs[kind] = (state.viewPrefs[kind]==='grid') ? 'list' : 'grid';
  storeSet(KEYS.VIEW_PREFS, state.viewPrefs);
  updateViewToggleBtn(kind);
  if(kind==='boats') renderBoats(); else renderCrew();
}
function updateViewToggleBtn(kind){
  const btn = document.getElementById(kind==='boats' ? 'boatsViewToggle' : 'crewViewToggle');
  if(!btn) return;
  const isGrid = state.viewPrefs[kind]==='grid';
  btn.classList.toggle('active', isGrid);
  // Icon shows the view you'd switch TO, matching the convention used by
  // most list/grid toggles (tap the grid icon to switch into grid view).
  btn.innerHTML = isGrid
    ? '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><path d="M3 6h18M3 12h18M3 18h18"/></svg>'
    : '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.8"><rect x="3" y="3" width="7" height="7" rx="1.5"/><rect x="14" y="3" width="7" height="7" rx="1.5"/><rect x="3" y="14" width="7" height="7" rx="1.5"/><rect x="14" y="14" width="7" height="7" rx="1.5"/></svg>';
  btn.title = isGrid ? t('action.viewAsList') : t('action.viewAsGrid');
}
// Features still being built. While a flag is true, its button shows a
// "Coming soon" tag and tapping it just explains that, instead of opening a
// half-finished screen. Set to false (and remove nothing else) when it's ready.
const FEATURES_IN_DEVELOPMENT = {
  pdfExport: true,
  certificate: false, // built (js/certificate.js) — A4 landscape PDF
};
// Returns true (and shows the message) if the feature is still in development,
// so callers can do: if(featureComingSoon('pdfExport')) return;
function featureComingSoon(key){
  if(!FEATURES_IN_DEVELOPMENT[key]) return false;
  showToast(t('toast.comingSoon'));
  return true;
}
// The little tag shown on a button whose feature is in development ('' otherwise).
function comingSoonTag(key){
  return FEATURES_IN_DEVELOPMENT[key] ? `<span class="soon-tag">${t('common.comingSoon')}</span>` : '';
}
function showToast(msg){
  const toastEl = document.getElementById('toast'); toastEl.textContent = msg; toastEl.classList.add('show');
  clearTimeout(window._toastTimer);
  window._toastTimer = setTimeout(()=>toastEl.classList.remove('show'), 2200);
}
function closeSheets(fromPopState){
  // Sheets (modals) are just divs toggled between display:none/block — hiding "all of them"
  // is simplest since only one is ever open at a time anyway.
  const wasOpen = [...document.querySelectorAll('.sheet')].some(s=>s.style.display==='block');
  document.querySelectorAll('.sheet').forEach(s=>s.style.display='none');
  document.getElementById('overlay').classList.remove('active');
  crewPickerActive = false;
  // Pop the history entry the open sheet was holding — but only when WE'RE
  // the ones closing it (a Cancel/Save/backdrop tap). If this close is a
  // reaction to the back button (fromPopState), the browser already moved
  // back on its own; calling history.back() again here would skip an extra
  // entry and throw the back-stack out of sync.
  if(wasOpen && !fromPopState){
    ignoreNextPopState = true;
    history.back();
  }
}
function openSheet(id){
  const wasSheetOpen = [...document.querySelectorAll('.sheet')].some(s=>s.style.display==='block');
  document.querySelectorAll('.sheet').forEach(s=>s.style.display='none');
  document.getElementById(id).style.display='block';
  document.getElementById('overlay').classList.add('active');
  // Swapping from one sheet straight to another (e.g. the photo adjuster
  // returning to the boat/crew sheet it was opened from) replaces the
  // current history entry rather than stacking a new one — otherwise each
  // hop through a chain of sheets would need its own extra back-press to
  // fully back out of, even though only one sheet is ever visible at a time.
  const state = {type:'sheet', id};
  if(wasSheetOpen){
    history.replaceState(state, '', location.href);
  } else {
    history.pushState(state, '', location.href);
  }
}

/* ---------- Android back-button integration ----------
   A PWA has no navigation history by default, so the phone's back button
   just exits the app immediately — this is what was happening. nav() and
   openSheet() above push a history entry per screen/sheet; this listener
   uses those entries to step back through the app instead, and only once
   you're back at Home with nothing open does a further back press fall
   through to actually exiting, which is the expected behavior.
   ignoreNextPopState suppresses the popstate our OWN history.back() call
   (from closeSheets) generates, so we don't double-handle it. ---------- */
let ignoreNextPopState = false;
window.addEventListener('popstate', (event)=>{
  if(ignoreNextPopState){ ignoreNextPopState = false; return; }
  // The photo viewer sits above everything (it can even be opened from a sheet), so it closes first.
  const lightboxEl = document.getElementById('photoLightbox');
  if(lightboxEl && lightboxEl.classList.contains('show')){ closeLightbox(true); return; }
  const sheetOpen = [...document.querySelectorAll('.sheet')].some(s=>s.style.display==='block');
  if(sheetOpen){
    closeSheets(true);
  } else {
    const target = (event.state && event.state.type==='screen') ? event.state.name : 'home';
    nav(target, true);
  }
});

/* ---------- hardware back button (Capacitor native shell only) ----------
   In the wrapped Android app, Capacitor's bridge dispatches a 'backButton'
   event via the @capacitor/app plugin instead of firing a normal
   popstate/history.back() the way a browser back gesture would. If nothing
   listens for it, Capacitor's own default behavior is to minimize the app
   (moveTaskToBack) — which is exactly the "hardware back just minimizes,
   no matter what screen I'm on" behavior this replaces. Hooking it here and
   funneling it into history.back() lets it reuse all the existing
   popstate/closeSheets()/nav() logic above, so a sheet closes first, then
   screens step back one at a time, and only a press from Home with nothing
   open falls through to the platform default (minimize). Web/PWA installs
   never fire this event, so this is a no-op there. ---------- */
function initHardwareBackButton(){
  const isNative = window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform();
  if(!isNative){ console.log('[backbutton] not running in the native shell — skipping (expected on web/PWA).'); return; }
  const AppPlugin = window.Capacitor.Plugins && window.Capacitor.Plugins.App;
  if(!AppPlugin || !AppPlugin.addListener){
    // If you see this line in chrome://inspect / Logcat, the @capacitor/app
    // plugin isn't registered on the native side, so there is nothing here
    // for the web layer to hook into — the hardware button keeps doing
    // Android's own default (minimize) no matter what this file does.
    // Fix: `npm install @capacitor/app` in the project root, then
    // `npx cap sync android`, then rebuild in Android Studio. Also check
    // android/app/src/main/java/.../MainActivity.java hasn't got its own
    // onBackPressed() override — a custom one there would intercept the
    // press before it ever reaches this JS listener.
    console.warn('[backbutton] Capacitor.Plugins.App is not available — @capacitor/app is likely not installed/synced natively. See the comment above this line in state-core.js for the fix.');
    return;
  }
  AppPlugin.addListener('backButton', () => {
    console.log('[backbutton] hardware back pressed — handling in-app.');
    const sheetOpen = [...document.querySelectorAll('.sheet')].some(s=>s.style.display==='block');
    const onHome = document.getElementById('screen-home').classList.contains('active');
    const lightboxOpen = document.getElementById('photoLightbox').classList.contains('show');
    if(sheetOpen || lightboxOpen || !onHome){
      history.back(); // handled by the popstate listener above, same as a browser back gesture
      return;
    }
    // Already at Home with nothing open — nothing left to step back through,
    // so hand it to the platform's own default (minimizes on Android).
    if(AppPlugin.minimizeApp) AppPlugin.minimizeApp();
    else if(AppPlugin.exitApp) AppPlugin.exitApp();
  });
  console.log('[backbutton] listener registered successfully.');
}

/* ---------- fit the app to the device (phones vs tablets) ----------
   The layout is a phone-shaped column (max 480px wide). On a phone that fills the screen.
   On a tablet it used to sit in the middle as a small strip. Now, when the device's short
   side is 600dp or more (the usual definition of "tablet"), the page's viewport is set so the
   whole UI is scaled up to fill the screen — up to 1.5x, which keeps the column a comfortable
   width (about 720dp) on big screens rather than stretching it. Phones are left exactly as they
   were. Re-checked whenever the device is rotated. screen.width/height are in device-independent
   pixels, so this doesn't depend on the current zoom. ---------- */
(function fitToDevice(){
  const meta = document.querySelector('meta[name="viewport"]');
  if(!meta) return;
  const BASE_W = 480, MAX_SCALE = 1.5, TABLET_MIN_SHORT_SIDE = 600;
  const PHONE = 'width=device-width, initial-scale=1.0, viewport-fit=cover';
  function apply(){
    const shortSide = Math.min(screen.width, screen.height), longSide = Math.max(screen.width, screen.height);
    const landscape = window.matchMedia('(orientation: landscape)').matches;
    const deviceW = landscape ? longSide : shortSide;
    let content = PHONE;
    if(shortSide >= TABLET_MIN_SHORT_SIDE){
      const scale = Math.min(deviceW / BASE_W, MAX_SCALE);
      content = 'width=' + Math.round(deviceW / scale) + ', viewport-fit=cover';
    }
    if(meta.getAttribute('content') !== content) meta.setAttribute('content', content);
  }
  apply();
  let t; const later = ()=>{ clearTimeout(t); t = setTimeout(apply, 250); };
  window.addEventListener('orientationchange', later);
  window.addEventListener('resize', later);
})();

/* ---------- image resize helper (keeps localStorage payloads small) ---------- */
function resizeImage(file, maxDim, quality){
  return new Promise((resolve,reject)=>{
    const reader = new FileReader();
    reader.onerror = ()=>reject(new Error('read failed'));
    reader.onload = ()=>{
      const img = new Image();
      img.onerror = ()=>reject(new Error('decode failed'));
      img.onload = ()=>{
        let w=img.width, h=img.height;
        if(w>h && w>maxDim){ h=Math.round(h*maxDim/w); w=maxDim; }
        else if(h>=w && h>maxDim){ w=Math.round(w*maxDim/h); h=maxDim; }
        const c=document.createElement('canvas'); c.width=w; c.height=h;
        c.getContext('2d').drawImage(img,0,0,w,h);
        resolve(c.toDataURL('image/jpeg', quality||0.7));
      };
      img.src = reader.result;
    };
    reader.readAsDataURL(file);
  });
}

/* ---------- photo adjuster: drag to reposition, slider to zoom, used for
   profile avatar & crew photos ---------- */
let adjustState = null; // { naturalImg, naturalW, naturalH, baseScale, baseW, baseH, zoom, left, top, vw, vh, shape, outputW, outputH, target, returnSheetId }
function readFileAsDataUrl(file){
  return new Promise((resolve,reject)=>{
    const r = new FileReader();
    r.onerror = ()=>reject(new Error('read failed'));
    r.onload = ()=>resolve(r.result);
    r.readAsDataURL(file);
  });
}
// Opens the crop/zoom sheet for a given file. Loads it at "cover fit" (baseScale)
// so the viewport starts fully covered, centered, with zoom=1.
// opts: { shape:'circle'|'rect', vw, vh, outputW, outputH } — defaults to the
// original 260x260 circular avatar crop if omitted, for profile/crew photos.
// Boats and trip covers pass a wide rect instead (see openBoatPhotoAdjuster /
// openCoverPhotoAdjuster below).
async function openPhotoAdjuster(file, target, returnSheetId, opts){
  if(!file) return;
  let dataUrl;
  try{ dataUrl = await readFileAsDataUrl(file); }
  catch(e){ showToast(t('toast.photoReadFail')); return; }
  startPhotoAdjuster(dataUrl, target, returnSheetId, opts);
}
// Same as openPhotoAdjuster but for a photo that's already a dataURL (e.g. one
// of a trip's existing photos, when picking/cropping a cover) rather than a
// fresh File from a file input.
function startPhotoAdjuster(dataUrl, target, returnSheetId, opts){
  opts = opts || {};
  const shape = opts.shape || 'circle';
  const vw = opts.vw || 260, vh = opts.vh || 260;
  const outputW = opts.outputW || 500, outputH = opts.outputH || 500;
  const img = new Image();
  img.onload = ()=>{
    const baseScale = Math.max(vw/img.naturalWidth, vh/img.naturalHeight);
    const baseW = img.naturalWidth*baseScale, baseH = img.naturalHeight*baseScale;
    adjustState = {
      naturalImg:img, naturalW:img.naturalWidth, naturalH:img.naturalHeight,
      baseScale, baseW, baseH, zoom:1,
      left:(vw-baseW)/2, top:(vh-baseH)/2,
      vw, vh, shape, outputW, outputH, target, returnSheetId: returnSheetId||null
    };
    const vp = document.getElementById('adjustViewport');
    vp.style.width = vw+'px'; vp.style.height = vh+'px';
    vp.style.borderRadius = shape==='circle' ? '50%' : '14px';
    vp.style.maxWidth = '100%';
    document.getElementById('adjustPreviewImg').src = dataUrl;
    document.getElementById('adjustZoomSlider').value = 1;
    renderAdjustTransform();
    openSheet('sheetPhotoAdjust');
    setupAdjustDrag();
  };
  img.onerror = ()=> showToast(t('toast.photoReadFail'));
  img.src = dataUrl;
}
// Applies the current zoom/position to the actual <img> element in the viewport —
// pure display, no math beyond what's already stored on adjustState.
function renderAdjustTransform(){
  const s = adjustState; if(!s) return;
  const el = document.getElementById('adjustPreviewImg');
  const dispW = s.baseW*s.zoom, dispH = s.baseH*s.zoom;
  el.style.width = dispW+'px'; el.style.height = dispH+'px';
  el.style.left = s.left+'px'; el.style.top = s.top+'px';
}
// Keeps the image from being dragged/zoomed so far that it no longer covers the
// full viewport (i.e. no empty gaps at the edges) — works for circle or rect.
function clampAdjustPosition(){
  const s = adjustState; if(!s) return;
  const dispW = s.baseW*s.zoom, dispH = s.baseH*s.zoom;
  const minLeft = s.vw-dispW, minTop = s.vh-dispH;
  s.left = Math.min(0, Math.max(minLeft, s.left));
  s.top = Math.min(0, Math.max(minTop, s.top));
}
function onAdjustZoomInput(){
  if(!adjustState) return;
  adjustState.zoom = parseFloat(document.getElementById('adjustZoomSlider').value)||1;
  clampAdjustPosition();
  renderAdjustTransform();
}
// Pointer-drag panning — Pointer Events cover mouse, touch, and pen in one
// listener set, so this works the same on desktop and phone.
function setupAdjustDrag(){
  const vp = document.getElementById('adjustViewport');
  if(vp._adjustBound) return; // only wire listeners once, state resets via adjustState
  vp._adjustBound = true;
  let dragging=false, startX=0, startY=0, startLeft=0, startTop=0;
  vp.addEventListener('pointerdown', (e)=>{
    if(!adjustState) return;
    dragging=true; startX=e.clientX; startY=e.clientY;
    startLeft=adjustState.left; startTop=adjustState.top;
    vp.setPointerCapture(e.pointerId);
  });
  vp.addEventListener('pointermove', (e)=>{
    if(!dragging || !adjustState) return;
    adjustState.left = startLeft + (e.clientX-startX);
    adjustState.top = startTop + (e.clientY-startY);
    clampAdjustPosition();
    renderAdjustTransform();
  });
  const endDrag = ()=>{ dragging=false; };
  vp.addEventListener('pointerup', endDrag);
  vp.addEventListener('pointercancel', endDrag);
}
function cancelPhotoAdjust(){
  const returnTo = adjustState?.returnSheetId;
  adjustState = null;
  if(returnTo) openSheet(returnTo); else closeSheets();
}
// Renders the final crop to a canvas and saves it. The math converts from
// "displayed viewport pixels" back to "original photo pixels" using k (the
// combined cover-fit + zoom scale factor), then crops exactly what's visible
// in the viewport into a fixed-size output image (outputW x outputH — square
// for avatars, wide for boat/cover photos).
async function confirmPhotoAdjust(){
  const s = adjustState; if(!s) return;
  const k = s.baseScale*s.zoom; // displayed px per natural px
  const srcX = (0 - s.left)/k, srcY = (0 - s.top)/k;
  const srcW = s.vw/k, srcH = s.vh/k;
  const c = document.createElement('canvas'); c.width=s.outputW; c.height=s.outputH;
  c.getContext('2d').drawImage(s.naturalImg, srcX, srcY, srcW, srcH, 0, 0, s.outputW, s.outputH);
  const dataUrl = c.toDataURL('image/jpeg', 0.85);

  if(s.target==='profile'){
    state.profile.avatar = dataUrl;
    await storeSet(KEYS.PROFILE, state.profile);
    refreshAvatars();
    syncProfileIfSignedIn();
    refreshProfileIfVisible(); // post avatars
    showToast(t('toast.photoUpdated'));
  } else if(s.target==='profileCover'){
    state.profile.cover = dataUrl;
    await storeSet(KEYS.PROFILE, state.profile);
    renderProfileHeader();
    syncProfileIfSignedIn();
    showToast(t('toast.photoUpdated'));
  } else if(s.target==='crew'){
    pendingCrewPhoto = dataUrl;
    document.getElementById('crewPhotoPreview').src = dataUrl;
  } else if(s.target==='boat'){
    pendingBoatPhotos.push(dataUrl);
    if(!pendingBoatPhoto) pendingBoatPhoto = dataUrl; // first photo added becomes the default automatically
    renderBoatPhotoStrip();
    if(pendingBoatFilesQueue.length){
      adjustState = null;
      continueBoatPhotoQueue();
      return; // stay on the adjuster for the next queued photo instead of returning to sheetBoat yet
    }
  } else if(s.target==='cover'){
    currentTrip.coverPhoto = dataUrl;
  }
  const returnTo = s.returnSheetId;
  adjustState = null;
  if(returnTo) openSheet(returnTo); else closeSheets();
}

/* ============================================================
   HOME
   ============================================================ */
