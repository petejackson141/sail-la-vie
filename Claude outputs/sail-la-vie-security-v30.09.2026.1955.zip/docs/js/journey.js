// ===== journey.js =====
// Home stats, starting a journey, crew/skipper pickers, GPS tracking, live photo capture, ending + saving a journey
// Extracted from the original single-file app.js, lines 1777-2539, in original order.

// "Last Sail" card under the Home buttons: the most recent sail by sail date
// (same ordering as History — not by when the entry was saved), tapping it opens
// that sail's detail screen. Called from renderHomeStats(), which already runs
// everywhere the trip list changes (save, delete, edit, sync, language switch).
function renderLastSail(){
  const wrap = document.getElementById('lastSailWrap');
  if(!wrap) return;
  if(!state.tripIndex.length){ wrap.innerHTML = ''; return; }
  const last = state.tripIndex.slice().sort((a,b)=>new Date(b.date)-new Date(a.date))[0];
  const dateStr = new Date(last.date).toLocaleDateString(currentLocale(), {day:'numeric', month:'short', year:'numeric'});
  const meta = [dateStr, last.place ? escapeHtml(last.place) : ''].filter(Boolean).join(' · ');
  const stats = [fmtDistance(last.distanceNm||0), last.elapsedSeconds ? fmtDuration(last.elapsedSeconds) : ''].filter(Boolean).join(' · ');
  wrap.innerHTML = `<div class="nt-last-sail" onclick="openTripDetail('${safeId(last.id)}','home')">
    <span class="nt-ls-pin" aria-hidden="true">📍</span>
    <div class="nt-ls-text">
      <div class="nt-ls-label">${t('home.lastSail')}</div>
      <div class="nt-ls-title">${escapeHtml(last.title || t('detail.tripFallback'))}</div>
      <div class="nt-ls-meta">${[stats, meta].filter(Boolean).join(' · ')}</div>
    </div>
    ${last.coverPhoto ? `<img class="nt-ls-thumb" src="${safeSrc(last.coverPhoto)}" alt="">` : ''}
    <svg class="nt-ls-chev" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 6l6 6-6 6"/></svg>
  </div>`;
}
function renderHomeStats(){
  refreshProfileIfVisible(); // Profile stats + posts follow the trip list too
  renderLastSail();
  const el = document.getElementById('homeStatsStrip');
  if(!state.tripIndex.length){ el.innerHTML=''; return; }
  const nm = state.tripIndex.reduce((s,t)=>s+(t.distanceNm||0),0);
  const secs = state.tripIndex.reduce((s,t)=>s+(t.elapsedSeconds||0),0);
  // Two separate cards, not one merged box — see the Home mockup work this followed.
  el.innerHTML = `<div class="nt-stats">
    <div class="nt-stat-cell"><div class="nt-stat-label">${t('resume.totalSails')}</div><div class="nt-stat-value">${state.tripIndex.length}</div></div>
    <div class="nt-stat-cell"><div class="nt-stat-label">${t('home.distanceLogged')}</div><div class="nt-stat-value">${nm.toFixed(1)}<span class="nt-stat-unit"> NM</span></div></div>
  </div>`;
}

/* ============================================================
   START / ACTIVE JOURNEY
   The "screen-active" HTML section does triple duty: a live GPS-tracked
   journey, a manually-entered past sail, and editing an existing trip all
   share this one screen and form — see beginJourney/beginManualJourney/editTrip
   below for how each mode sets it up differently.
   ============================================================ */
function populateBoatSelects(){
  const opts = state.boats.length
    ? `<option value="" disabled selected>${t('sheet.chooseBoatOpt')}</option>` + state.boats.map(b=>`<option value="${b.id}">${escapeHtml(b.name)}</option>`).join('')
    : `<option value="">${t('sheet.noBoatsOpt')}</option>`;
  document.getElementById('startBoatSelect').innerHTML = opts;
  document.getElementById('activeBoatSelect').innerHTML = opts;
}
async function openStartJourneySheet(){
  if(currentTrip){
    if(await confirmDialog('journeyInProgress', {icon:'pin'})){
      nav('active');
      return;
    }
    return;
  }
  populateBoatSelects();
  openSheet('sheetStartJourney');
}
/* ---- weather slider labels & the per-entry unit toggle ----
   Sliders (windSpeed, gusts) always STORE kts internally regardless of what's
   displayed — activeUnitSystem only changes the label text via fmtSpeed(). This
   keeps the data model simple: one canonical unit, converted for display only. */
function updateWindSpeedLabel(){
  const kts = parseFloat(document.getElementById('windSpeed').value)||0;
  document.getElementById('windSpeedVal').textContent = (kts===0 ? '0 kts (Calm)' : fmtSpeed(kts, activeUnitSystem)).replace('kts', speedUnitLabel(activeUnitSystem));
}
function updateWaveHeightLabel(){
  const v = parseFloat(document.getElementById('waveHeight').value).toFixed(1);
  document.getElementById('waveHeightVal').textContent = v+' m';
}
function updateTempLabel(){
  const v = document.getElementById('temp').value;
  document.getElementById('tempVal').textContent = v+'°C';
}
function updateGustsLabel(){
  const kts = parseFloat(document.getElementById('gusts').value)||0;
  document.getElementById('gustsVal').textContent = fmtSpeed(kts, activeUnitSystem);
}
/* ---- auto-fill weather at Cast Off ----
   Pre-fills the wind/wave/sky fields above from live conditions at the
   boat's current position, using Open-Meteo (free, no API key —
   https://open-meteo.com) — one call to their general forecast API for
   wind/temp/sky, one to their marine API for wave height/direction. This is
   a ONE-TIME snapshot taken at the moment of Cast Off, not a live feed: the
   fields stay ordinary editable sliders/dropdowns afterward, exactly as if
   the sailor had set them by hand, so anything here can still be corrected
   before or after the sail.
   Note: gusts don't get their own direction field, here or in the weather
   data itself — a gust is a brief spike in speed within the SAME prevailing
   wind, not an independently measured direction, so gust speed is shown
   alongside the one wind direction rather than a fabricated second value.
   Best-effort: if there's no connectivity yet at the dock, or geolocation
   fails, this silently leaves the fields at their normal defaults — it
   never blocks or interrupts Cast Off. */
function degToCompass8(deg){
  if(deg==null || isNaN(deg)) return null;
  const dirs = ['N','NE','E','SE','S','SW','W','NW'];
  return dirs[Math.round((((deg%360)+360)%360)/45)%8];
}
function weatherCodeToSky(code){
  if(code==null) return null;
  if(code===0) return 'Clear / Sunny';
  if(code===1 || code===2) return 'Partly Cloudy';
  if(code===3) return 'Cloudy';
  if(code===45 || code===48) return 'Fog';
  if(code>=51 && code<=67) return 'Rain';
  if(code>=71 && code<=77 || code===85 || code===86) return 'Snow';
  if(code>=80 && code<=82) return 'Rain';
  if(code>=95) return 'Thunderstorm';
  return null;
}
function waveHeightToSeaState(m){
  if(m==null || isNaN(m)) return null;
  if(m<0.5) return 'Calm';
  if(m<1.25) return 'Slight';
  if(m<2.5) return 'Moderate';
  if(m<4) return 'Rough';
  return 'Very Rough';
}
function autoFillWeatherAtCastOff(){
  if(!('geolocation' in navigator)) return;
  navigator.geolocation.getCurrentPosition(
    (pos)=> applyAutoWeather(pos.coords.latitude, pos.coords.longitude),
    ()=>{}, // no position yet (no signal at the dock) — fields just keep their defaults
    {enableHighAccuracy:true, timeout:15000, maximumAge:60000}
  );
}
async function applyAutoWeather(lat, lng){
  try{
    const [wxRes, marineRes] = await Promise.all([
      fetch(`https://api.open-meteo.com/v1/forecast?latitude=${lat}&longitude=${lng}&current=temperature_2m,weather_code,wind_speed_10m,wind_direction_10m,wind_gusts_10m&wind_speed_unit=kn`),
      fetch(`https://marine-api.open-meteo.com/v1/marine?latitude=${lat}&longitude=${lng}&current=wave_height,wave_direction`)
    ]);
    // currentTrip may have been discarded/ended while these requests were in
    // flight — bail out rather than filling in a form that's no longer live.
    if(!currentTrip || currentTrip.isManual) return;
    const wx = wxRes.ok ? (await wxRes.json()).current : null;
    const marine = marineRes.ok ? (await marineRes.json()).current : null;
    let filledAny = false;
    if(wx){
      const dir = degToCompass8(wx.wind_direction_10m);
      if(dir){ document.getElementById('windDir').value = dir; filledAny = true; }
      if(wx.wind_speed_10m!=null){ document.getElementById('windSpeed').value = Math.max(0,Math.min(19,Math.round(wx.wind_speed_10m))); updateWindSpeedLabel(); filledAny = true; }
      if(wx.wind_gusts_10m!=null){ document.getElementById('gusts').value = Math.max(0,Math.min(40,Math.round(wx.wind_gusts_10m))); updateGustsLabel(); filledAny = true; }
      if(wx.temperature_2m!=null){ document.getElementById('temp').value = Math.max(0,Math.min(50,Math.round(wx.temperature_2m))); updateTempLabel(); filledAny = true; }
      const sky = weatherCodeToSky(wx.weather_code);
      if(sky){ document.getElementById('sky').value = sky; filledAny = true; }
    }
    if(marine){
      const dir = degToCompass8(marine.wave_direction);
      if(dir){ document.getElementById('waveDir').value = dir; filledAny = true; }
      if(marine.wave_height!=null){
        document.getElementById('waveHeight').value = Math.max(0,Math.min(5,marine.wave_height)).toFixed(1);
        updateWaveHeightLabel();
        const seaState = waveHeightToSeaState(marine.wave_height);
        if(seaState){ document.getElementById('seaState').value = seaState; }
        filledAny = true;
      }
    }
    if(filledAny){
      const bits = [];
      const skyVal = document.getElementById('sky').value;
      if(skyVal) bits.push(`${skyIcon(skyVal)} ${skyLabel(skyVal)}`);
      if(wx && wx.wind_direction_10m!=null) bits.push(`💨 ${compassLabel(document.getElementById('windDir').value)} ${fmtSpeed(parseFloat(document.getElementById('windSpeed').value)||0, activeUnitSystem)}`);
      if(marine && marine.wave_height!=null) bits.push(`🌊 ${document.getElementById('waveHeight').value}m`);
      if(wx && wx.temperature_2m!=null) bits.push(`🌡 ${document.getElementById('temp').value}°C`);
      showWeatherAutoFillBanner(bits.join(' · '));
    }
  }catch(e){ /* no connectivity or the request failed — fields just keep their defaults */ }
}
function showWeatherAutoFillBanner(summary){
  const banner = document.getElementById('weatherAutoFillBanner');
  if(!banner) return;
  document.getElementById('weatherAutoFillText').textContent = t('active.weatherAutoFillBanner', {summary});
  banner.style.display = 'flex';
}
function dismissWeatherAutoFillBanner(){
  const banner = document.getElementById('weatherAutoFillBanner');
  if(banner) banner.style.display = 'none';
}
// Tapping the banner (not its ✕) jumps straight to the weather fields it's
// describing, since they sit well below the fold on this screen.
function scrollToLogEntryWeather(event){
  if(event && event.target.closest('.dismiss')) return;
  const el = document.getElementById('sky');
  if(el) el.scrollIntoView({behavior:'smooth', block:'center'});
}
// The little ⚓/🌍 switch on the log screen. Unlike wind speed/gusts (which
// stay in kts and only relabel), the distance fields hold whatever unit is
// currently selected — so flipping here has to actually convert their typed
// values, not just relabel them.
function toggleLogUnitSystem(){
  const from = activeUnitSystem;
  const to = from==='metric' ? 'nautical' : 'metric';
  // NM<->km and kts<->km/h share the same 1.852 factor, so distance and speed
  // fields can all run through the same conversion loop.
  ['manualDistance','pastDistance','pastAvgSpeed','pastMaxSpeed'].forEach(id=>{
    const el = document.getElementById(id);
    const v = parseFloat(el.value);
    if(!isNaN(v)){
      const canonical = from==='metric' ? v/NM_TO_KM : v;
      el.value = (to==='metric' ? canonical*NM_TO_KM : canonical).toFixed(1);
    }
  });
  activeUnitSystem = to;
  refreshLogUnitsUI();
}
// Refreshes the avg/max speed + distance stat cards on the active screen to
// match activeUnitSystem. Called after every GPS fix and whenever units flip.
// BUG FIX (see notes): fmtSpeed/fmtDistance default to the app-wide Settings unit
// when no 'sys' argument is passed. On the log screen specifically we must pass
// activeUnitSystem explicitly, or the local ⚓/🌍 toggle silently does nothing.
function updateLiveStatDisplays(){
  if(!currentTrip) return;
  document.getElementById('avgSpeedDisplay').innerHTML = fmtSpeed(currentTrip.avgSpeed||0, activeUnitSystem).replace(' ', '<span class="stat-unit"> ')+'</span>';
  document.getElementById('maxSpeedDisplay').innerHTML = fmtSpeed(currentTrip.maxSpeed||0, activeUnitSystem).replace(' ', '<span class="stat-unit"> ')+'</span>';
  document.getElementById('distDisplay').innerHTML = fmtDistance(currentTrip.distanceNm||0, activeUnitSystem).replace(' ', '<span class="stat-unit"> ')+'</span>';
}
// Re-renders every unit-dependent label on the log screen at once — call this
// after seeding activeUnitSystem at the start of a journey/entry/edit.
function refreshLogUnitsUI(){
  const sys = activeUnitSystem;
  const label = sys==='metric' ? t('unit.metric') : t('unit.nautical');
  const knob = sys==='metric' ? '🌍' : '⚓';
  // Two visible instances of the same toggle — one under the live stat-grid, one
  // under the manual/edit distance field — both drive the same activeUnitSystem.
  document.getElementById('logUnitsKnobLive').textContent = knob;
  document.getElementById('logUnitsLabelLive').textContent = label;
  document.getElementById('logUnitsKnobPast').textContent = knob;
  document.getElementById('logUnitsLabelPast').textContent = label;
  document.getElementById('manualDistanceLabel').textContent = t('active.manualDistanceLabel', {unit: distUnitLabel(sys)});
  document.getElementById('pastDistanceLabel').textContent = t('active.distanceUnitLabel', {unit: distUnitLabel(sys)});
  document.getElementById('pastAvgSpeedLabel').textContent = t('active.avgSpeedUnitLabel', {unit: speedUnitLabel(sys)});
  document.getElementById('pastMaxSpeedLabel').textContent = t('active.maxSpeedUnitLabel', {unit: speedUnitLabel(sys)});
  updateWindSpeedLabel();
  updateGustsLabel();
  updateLiveStatDisplays();
}
/* ---- crew picker: only crew explicitly added to THIS trip show on the log
   screen (not the whole roster) — see renderAddedCrewChips vs renderCrewPickList ---- */
const SKIPPER_SELF_ID = 'self'; // sentinel id for "me" (state.profile), distinct from any crew uid()
// Resolves a crewIds/skipperId entry to a displayable {name,photo}. Handles
// the SKIPPER_SELF_ID sentinel (the profile owner, offered as a locked pick
// in both the crew and skipper pickers) as well as real saved crew members.
function crewMemberById(id){
  if(!id) return null;
  if(id===SKIPPER_SELF_ID) return { name: state.profile.name||t('default.sailorName'), photo: state.profile.avatar||'' };
  return state.crew.find(c=>c.id===id) || null;
}
function renderAddedCrewChips(){
  const row = document.getElementById('addedCrewRow');
  const added = (currentTrip?.crewIds||[]).map(id=>{ const m = crewMemberById(id); return m ? {...m, id} : null; }).filter(Boolean);
  if(!added.length){ row.innerHTML = `<p style="font-size:12.5px;">No crew added yet — tap "+ Add Crew" below.</p>`; return; }
  row.innerHTML = added.map(c=>`
    <div class="crew-chip active">
      <img src="${safeSrc(c.photo||placeholderAvatar())}"><span>${escapeHtml(c.name)}</span>
      <div class="rm" onclick="removeAddedCrew('${c.id}')">✕</div>
    </div>`).join('');
}
function removeAddedCrew(id){
  currentTrip.crewIds = (currentTrip.crewIds||[]).filter(cid=>cid!==id);
  renderAddedCrewChips();
}
let crewPickTempIds = [];   // draft selection while the "Add Crew" sheet is open — only committed to currentTrip.crewIds on Done
let crewPickerActive = false; // true while "+ Add New Crew Member" is open from inside the picker, so saveCrewForm() knows to return here instead of the Crew tab
function openSelectCrewSheet(){
  crewPickTempIds = [...(currentTrip.crewIds||[])];
  renderCrewPickList();
  openSheet('sheetSelectCrew');
}
function renderCrewPickList(){
  const el = document.getElementById('crewPickList');
  // The profile owner is always offered here — even before any crew has been
  // added — as a locked, non-editable row, so they can mark themselves as
  // aboard without it looking like they weren't on the sail. It only ever
  // appears in this picker, never in the managed Crew roster (renderCrew),
  // and there's no way to edit or delete it from here.
  const selfRow = `
    <div class="crew-pick-row${crewPickTempIds.includes(SKIPPER_SELF_ID)?' selected':''}" data-id="${SKIPPER_SELF_ID}" onclick="toggleCrewPick('${SKIPPER_SELF_ID}')">
      <img src="${safeSrc(state.profile.avatar||placeholderAvatar())}">
      <div class="name">${escapeHtml(state.profile.name||t('default.sailorName'))} ${t('active.youSuffix')}</div>
      <div class="crew-pick-check"></div>
    </div>`;
  const crewRows = [...state.crew].sort((a,b)=>a.name.localeCompare(b.name)).map(c=>`
    <div class="crew-pick-row${crewPickTempIds.includes(c.id)?' selected':''}" data-id="${c.id}" onclick="toggleCrewPick('${c.id}')">
      <img src="${safeSrc(c.photo||placeholderAvatar())}">
      <div class="name">${escapeHtml(c.name)}</div>
      <div class="crew-pick-check"></div>
    </div>`).join('');
  el.innerHTML = selfRow + crewRows;
}
function toggleCrewPick(id){
  if(crewPickTempIds.includes(id)) crewPickTempIds = crewPickTempIds.filter(x=>x!==id);
  else crewPickTempIds.push(id);
  renderCrewPickList();
}
function confirmCrewPick(){
  currentTrip.crewIds = [...crewPickTempIds];
  closeSheets();
  renderAddedCrewChips();
}
function startAddCrewFromPicker(){
  crewPickerActive = true;
  openCrewSheet();
}

/* ---- skipper picker: single-select from the crew roster (plus the app's
   own profile, since the person logging the sail is often the skipper too),
   shown on this same shared screen for both live and manual/edit entries ---- */
function skipperById(id){ return crewMemberById(id); }
function renderSkipperChip(){
  const row = document.getElementById('skipperChipRow');
  const skipper = currentTrip?.skipperId ? skipperById(currentTrip.skipperId) : null;
  if(!skipper){ row.innerHTML = `<p style="font-size:12.5px;">No skipper set — tap "Choose Skipper" below.</p>`; return; }
  row.innerHTML = `
    <div class="crew-chip active">
      <img src="${safeSrc(skipper.photo||placeholderAvatar())}"><span>${escapeHtml(skipper.name)}</span>
      <div class="rm" onclick="clearSkipper()">✕</div>
    </div>`;
}
function clearSkipper(){
  currentTrip.skipperId = null;
  renderSkipperChip();
}
function openSelectSkipperSheet(){
  renderSkipperPickList();
  openSheet('sheetSelectSkipper');
}
function renderSkipperPickList(){
  const el = document.getElementById('skipperPickList');
  const selfRow = `
    <div class="crew-pick-row${currentTrip.skipperId===SKIPPER_SELF_ID?' selected':''}" data-id="${SKIPPER_SELF_ID}" onclick="selectSkipper('${SKIPPER_SELF_ID}')">
      <img src="${safeSrc(state.profile.avatar||placeholderAvatar())}">
      <div class="name">${escapeHtml(state.profile.name||t('default.sailorName'))} ${t('active.youSuffix')}</div>
      <div class="crew-pick-check"></div>
    </div>`;
  const crewRows = [...state.crew].sort((a,b)=>a.name.localeCompare(b.name)).map(c=>`
    <div class="crew-pick-row${currentTrip.skipperId===c.id?' selected':''}" data-id="${c.id}" onclick="selectSkipper('${c.id}')">
      <img src="${safeSrc(c.photo||placeholderAvatar())}">
      <div class="name">${escapeHtml(c.name)}</div>
      <div class="crew-pick-check"></div>
    </div>`).join('');
  el.innerHTML = selfRow + crewRows;
}
function selectSkipper(id){
  currentTrip.skipperId = id;
  closeSheets();
  renderSkipperChip();
}
function clearSkipperPick(){
  currentTrip.skipperId = null;
  closeSheets();
  renderSkipperChip();
}

// Shared field-reset used by both a fresh live journey and a fresh manual entry
// (NOT used by editTrip, which pre-fills from the existing trip instead).
function resetActiveFormFields(){
  dismissWeatherAutoFillBanner();
  document.getElementById('tripTitle').value = '';
  document.getElementById('tripPlace').value = '';
  document.getElementById('windSpeed').value = 8; updateWindSpeedLabel();
  document.getElementById('waveHeight').value = 0.5; updateWaveHeightLabel();
  document.getElementById('temp').value = 20; updateTempLabel();
  document.getElementById('gusts').value = 10; updateGustsLabel();
  document.getElementById('waveDir').value = 'N';
  document.getElementById('sky').value = 'Clear / Sunny';
  document.getElementById('activePhotoStrip').querySelectorAll('.photo-thumb').forEach(n=>n.remove());
  document.getElementById('tripNotes').value = '';
  document.getElementById('mapImagePreviewWrap').style.display = 'none';
  document.getElementById('mapImagePreview').src = '';
  renderSkipperChip();
  renderAddedCrewChips();
}
// MODE 1: live GPS journey. Creates a fresh currentTrip, starts the timer and
// GPS watch immediately. See beginManualJourney() and editTrip() for the other
// two ways this same screen gets used.
async function beginJourney(){
  const boatId = document.getElementById('startBoatSelect').value;
  currentTrip = {
    id: uid(),
    isManual: false,
    boatId: boatId || null,
    date: new Date().toISOString(),
    elapsedSeconds: 0,
    distanceNm: 0,
    avgSpeed: 0,
    maxSpeed: 0,
    path: [],
    weather: {}, place:'', notes:'', skipperId: null, crewIds: [], photos: [], coverPhoto: null, mapImage: null
  };
  activeUnitSystem = appUnitSystem();
  closeSheets();
  nav('active');
  document.getElementById('liveStatsBlock').style.display = 'block';
  document.getElementById('pastStatsBlock').style.display = 'none';
  document.getElementById('endJourneyBtnLabel').textContent = t('active.endJourney');
  resetActiveFormFields();
  // BUG FIX: the boat chosen in the Start Journey sheet never used to carry
  // over to the log form's own boat select — it silently sat on whatever the
  // browser auto-selected. Sync it explicitly now that there's a real value to sync.
  document.getElementById('activeBoatSelect').value = boatId || '';
  refreshLogUnitsUI();
  startedAt = Date.now();
  document.getElementById('elapsedDisplay').textContent = '00:00:00';
  updateLiveStatDisplays();
  timerId = setInterval(tickTimer, 1000);
  startGPS();
  startLiveConnCheck();
  requestWakeLock();
  autoFillWeatherAtCastOff();
  // Awaited deliberately, unlike the per-tick/per-fix checkpoints below: this is the
  // one-time "a journey now exists" write, and it's the only thing standing between
  // an instant crash right after tapping Cast Off and losing the journey entirely.
  await saveActiveTripCheckpoint();
}
// MODE 3: editing an existing trip. Deep-clones it into currentTrip (so
// discarding never touches the saved copy) and pre-fills every field, reusing
// the same "past sail" UI as manual entry. finalizeSaveTrip() checks
// currentTrip.isEditing to overwrite the original instead of creating a new trip.
function editTrip(){
  const trip = window._detailTrip;
  if(!trip){ showToast(t('toast.openTripFirst')); return; }
  if(window._friendDetail) return; // a friend's sail is read-only
  if(currentTrip){
    showToast(t('toast.finishOrDiscardFirst'));
    return;
  }
  currentTrip = JSON.parse(JSON.stringify(trip)); // deep clone so cancel never touches the saved version
  currentTrip.isManual = true;
  currentTrip.isEditing = true;
  activeUnitSystem = appUnitSystem();
  populateBoatSelects();
  nav('active');
  document.getElementById('liveStatsBlock').style.display = 'none';
  document.getElementById('pastStatsBlock').style.display = 'block';
  document.getElementById('endJourneyBtnLabel').textContent = t('active.saveChanges');

  document.getElementById('tripTitle').value = trip._customTitle ? trip.title : '';
  document.getElementById('tripPlace').value = trip.place || '';
  document.getElementById('activeBoatSelect').value = trip.boatId || '';
  document.getElementById('windDir').value = trip.weather?.windDir || 'N';
  // windSpeed may be a plain kts number (current format) or older saved text like "8.0 kts" — handle both
  const wsRaw = trip.weather?.windSpeed;
  const wsNum = typeof wsRaw === 'number' ? wsRaw : parseFloat(String(wsRaw||'').match(/[\d.]+/)?.[0]) || 8;
  document.getElementById('windSpeed').value = wsNum;
  const gustsRaw = trip.weather?.gusts;
  const gustsNum = typeof gustsRaw === 'number' ? gustsRaw : parseFloat(String(gustsRaw||'').match(/[\d.]+/)?.[0]) || 10;
  document.getElementById('gusts').value = gustsNum;
  document.getElementById('waveDir').value = trip.weather?.waveDir || 'N';
  document.getElementById('seaState').value = trip.weather?.seaState || 'Moderate';
  document.getElementById('waveHeight').value = trip.weather?.waveHeight || 0.5;
  document.getElementById('temp').value = trip.weather?.temp || 20;
  document.getElementById('tripNotes').value = trip.notes || '';
  refreshLogUnitsUI();
  updateWindSpeedLabel();
  updateGustsLabel();
  updateWaveHeightLabel();
  updateTempLabel();

  const d = new Date(trip.date);
  d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
  document.getElementById('pastDate').value = d.toISOString().slice(0,16);
  refreshPastDateDisplay();
  const totalMin = Math.round((trip.elapsedSeconds||0)/60);
  document.getElementById('pastHours').value = Math.floor(totalMin/60);
  document.getElementById('pastMinutes').value = totalMin%60;
  const distNm = trip.distanceNm || 0;
  document.getElementById('pastDistance').value = (activeUnitSystem==='metric' ? distNm*NM_TO_KM : distNm).toFixed(1);
  document.getElementById('pastAvgSpeed').value = fmtSpeed(trip.avgSpeed||0, activeUnitSystem).split(' ')[0];
  document.getElementById('pastMaxSpeed').value = fmtSpeed(trip.maxSpeed||0, activeUnitSystem).split(' ')[0];
  if(trip.mapImage){
    document.getElementById('mapImagePreview').src = trip.mapImage;
    document.getElementById('mapImagePreviewWrap').style.display = 'block';
  }

  renderSkipperChip();
  renderAddedCrewChips();
  renderActivePhotoStrip();
}
// Runs once on boot, before the home screen shows. If a journey/manual-entry/edit
// was still active when the tab last closed (screen-lock kill, browser reclaiming
// memory, accidental tab close, etc.), this restores it from the checkpoint saved by
// saveActiveTripCheckpoint() instead of silently losing it. For a live GPS journey,
// elapsed time is recomputed from the original startedAt (real wall-clock time), and
// the GPS watch + timer are restarted so tracking picks straight back up.
async function resumeActiveTripIfAny(){
  let ckpt;
  try{ ckpt = await storeGet(KEYS.ACTIVE_TRIP); }catch(e){ ckpt = null; }
  if(!ckpt || !ckpt.trip) return false;
  currentTrip = ckpt.trip;
  startedAt = ckpt.startedAt || Date.now();
  activeUnitSystem = appUnitSystem();
  populateBoatSelects();
  nav('active');
  const isLive = !currentTrip.isManual;
  document.getElementById('liveStatsBlock').style.display = isLive ? 'block' : 'none';
  document.getElementById('pastStatsBlock').style.display = isLive ? 'none' : 'block';
  document.getElementById('endJourneyBtnLabel').textContent = currentTrip.isEditing ? t('active.saveChanges') : currentTrip.isManual ? t('active.saveLogEntry') : t('active.endJourney');

  document.getElementById('tripTitle').value = currentTrip._customTitle ? currentTrip.title : '';
  document.getElementById('tripPlace').value = currentTrip.place || '';
  document.getElementById('activeBoatSelect').value = currentTrip.boatId || '';
  document.getElementById('windDir').value = currentTrip.weather?.windDir || 'N';
  document.getElementById('windSpeed').value = currentTrip.weather?.windSpeed ?? 8;
  document.getElementById('gusts').value = currentTrip.weather?.gusts ?? 10;
  document.getElementById('waveDir').value = currentTrip.weather?.waveDir || 'N';
  document.getElementById('seaState').value = currentTrip.weather?.seaState || 'Moderate';
  document.getElementById('waveHeight').value = currentTrip.weather?.waveHeight || 0.5;
  document.getElementById('temp').value = currentTrip.weather?.temp || 20;
  document.getElementById('sky').value = currentTrip.weather?.sky || 'Clear / Sunny';
  document.getElementById('tripNotes').value = currentTrip.notes || '';
  refreshLogUnitsUI();
  updateWindSpeedLabel(); updateGustsLabel(); updateWaveHeightLabel(); updateTempLabel();
  if(currentTrip.mapImage){
    document.getElementById('mapImagePreview').src = currentTrip.mapImage;
    document.getElementById('mapImagePreviewWrap').style.display = 'block';
  }
  renderSkipperChip();
  renderAddedCrewChips();
  renderActivePhotoStrip();

  if(isLive){
    updateLiveStatDisplays();
    timerId = setInterval(tickTimer, 1000);
    startGPS();
    startLiveConnCheck();
    requestWakeLock();
  } else {
    // Not a live journey (manual entry or edit draft): the duration/distance/speed
    // inputs on this screen aren't bound to currentTrip until Save is pressed, so
    // repopulate them the same way editTrip() does, from whatever was on currentTrip.
    const d = new Date(currentTrip.date);
    d.setMinutes(d.getMinutes() - d.getTimezoneOffset());
    document.getElementById('pastDate').value = d.toISOString().slice(0,16);
    refreshPastDateDisplay();
    const totalMin = Math.round((currentTrip.elapsedSeconds||0)/60);
    document.getElementById('pastHours').value = Math.floor(totalMin/60);
    document.getElementById('pastMinutes').value = totalMin%60;
    const distNm = currentTrip.distanceNm || 0;
    document.getElementById('pastDistance').value = (activeUnitSystem==='metric' ? distNm*NM_TO_KM : distNm).toFixed(1);
    document.getElementById('pastAvgSpeed').value = fmtSpeed(currentTrip.avgSpeed||0, activeUnitSystem).split(' ')[0];
    document.getElementById('pastMaxSpeed').value = fmtSpeed(currentTrip.maxSpeed||0, activeUnitSystem).split(' ')[0];
  }
  showToast(t('toast.tripResumed'));
  return true;
}
// MODE 2: manually logging a sail that already happened. No GPS/timer — the
// person fills in date, duration, and distance by hand instead.
async function beginManualJourney(){
  if(currentTrip){
    if(await confirmDialog('journeyInProgress', {icon:'pin'})){
      nav('active');
    }
    return;
  }
  populateBoatSelects();
  currentTrip = {
    id: uid(),
    isManual: true,
    boatId: null,
    date: new Date().toISOString(),
    elapsedSeconds: 0,
    distanceNm: 0,
    avgSpeed: 0,
    maxSpeed: 0,
    path: [],
    weather: {}, place:'', notes:'', skipperId: null, crewIds: [], photos: [], coverPhoto: null, mapImage: null
  };
  activeUnitSystem = appUnitSystem();
  nav('active');
  document.getElementById('liveStatsBlock').style.display = 'none';
  document.getElementById('pastStatsBlock').style.display = 'block';
  document.getElementById('endJourneyBtnLabel').textContent = t('active.saveLogEntry');
  resetActiveFormFields();
  refreshLogUnitsUI();
  // default the date/time picker to now, in local time, formatted for datetime-local
  const now = new Date();
  now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
  document.getElementById('pastDate').value = now.toISOString().slice(0,16);
  refreshPastDateDisplay();
  document.getElementById('pastHours').value = '';
  document.getElementById('pastMinutes').value = '';
  document.getElementById('pastDistance').value = '';
  document.getElementById('pastAvgSpeed').value = '';
  document.getElementById('pastMaxSpeed').value = '';
}
/* ---- live GPS: runs every second (timer) / on every position fix (GPS watch) ---- */
function tickTimer(){
  const secs = Math.floor((Date.now()-startedAt)/1000);
  currentTrip.elapsedSeconds = secs;
  const h = String(Math.floor(secs/3600)).padStart(2,'0');
  const m = String(Math.floor((secs%3600)/60)).padStart(2,'0');
  const s = String(secs%60).padStart(2,'0');
  document.getElementById('elapsedDisplay').textContent = `${h}:${m}:${s}`;
  const bannerTime = document.getElementById('recordingBannerTime');
  if(bannerTime) bannerTime.textContent = `${h}:${m}:${s}`;
  // Checkpoint every ~10s even without a GPS fix (e.g. anchored, weak signal) so
  // elapsed time is never more than ~10s stale if the tab gets killed.
  if(secs % 10 === 0) saveActiveTripCheckpoint();
}
// Great-circle distance between two lat/lng points, in nautical miles.
function haversineNm(a,b){
  const R=3440.065; // Earth's radius in nautical miles
  const toRad = d=>d*Math.PI/180;
  const dLat = toRad(b.lat-a.lat), dLon = toRad(b.lng-a.lng);
  const la1=toRad(a.lat), la2=toRad(b.lat);
  const h = Math.sin(dLat/2)**2 + Math.cos(la1)*Math.cos(la2)*Math.sin(dLon/2)**2;
  return R * 2 * Math.atan2(Math.sqrt(h), Math.sqrt(1-h));
}
// A fix worse than this radius (meters) is almost certainly the browser falling
// back to coarse network/cell positioning rather than a real GPS lock — common
// offshore with a weak cell signal. These used to get plotted straight onto the
// track, snapping the line miles off course. Tune this up if legit fixes at sea
// are getting rejected too often (weak-signal status will show if so); tune it
// down if occasional jumps still slip through.
const GPS_ACCURACY_LIMIT_M = 60;
// How long to go without ANY fix (good or bad) before we treat GPS as silently
// dead rather than just between fixes. watchPosition can stop delivering
// callbacks on mobile (especially iOS Safari/PWAs) without ever firing an
// error — nothing previously caught this, so the elapsed timer (which runs on
// its own independent setInterval) just kept counting while nothing recorded.
const GPS_STALE_MS = 45000;

// True when running inside the Capacitor native app (Android/iOS), false in
// the browser/PWA. Everything below branches on this so the web version keeps
// using the plain browser geolocation API unchanged, while the native app
// uses the @transistorsoft/capacitor-background-geolocation plugin — the piece that actually
// survives the screen locking or the app being backgrounded, which
// navigator.geolocation.watchPosition() cannot do on its own.
function isNativeApp(){
  return !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
}
// Loaded from vendor-background-geolocation.js (a plain-script bundle of
// @transistorsoft/capacitor-background-geolocation, built with esbuild since
// this app has no bundler of its own — see that file's header comment).
function getBgGeo(){
  return window.TSBackgroundGeolocationModule && window.TSBackgroundGeolocationModule.default;
}
let bgGeoReady = false; // true once .ready() has been called this app session — only needs doing once

// ---- Native tracker choice ----
// 'sail'           = our own free recorder (android/app/src/main/java/com/saillavie/app/tracking/)
// 'transistorsoft' = the paid plugin, kept only as a fallback until SailTracker
//                    has passed real-world testing. To switch back, change this
//                    one line, run `npx cap sync`, and rebuild.
// If 'sail' is chosen but the plugin isn't in the build, it falls back automatically.
const NATIVE_TRACKER = 'sail';
function getSailTracker(){
  return (isNativeApp() && window.Capacitor.Plugins && window.Capacitor.Plugins.SailTracker) || null;
}
function useSailTracker(){ return NATIVE_TRACKER === 'sail' && !!getSailTracker(); }

// SailTracker records every fix to phone storage first (so nothing is lost while
// the screen is off or the app is closed) and fires "fixesAvailable". We then
// take the whole queue and feed it through the SAME onFix() path as always —
// real GPS timestamps and all — so none of the tested filtering logic changes.
let sailTrackerListenerAdded = false;
let drainingSailFixes = false;
// True while replaying a batch: commitFix() then skips the per-fix redraw and
// checkpoint save, and we do both once at the end instead. After 30 minutes of
// screen-off that's one redraw instead of ~1,800.
let batchingFixes = false;
async function drainSailTrackerFixes(){
  const tracker = getSailTracker();
  if(!tracker || drainingSailFixes || !currentTrip || currentTrip.isManual) return;
  drainingSailFixes = true;
  try{
    const { fixes } = await tracker.takeFixes();
    if(fixes && fixes.length && currentTrip){
      // Ignore anything from before this journey started, or already on the
      // track (e.g. fixes replayed after the app was reopened).
      const lastT = currentTrip.path.length ? currentTrip.path[currentTrip.path.length-1].t : 0;
      const floorT = Math.max(lastT, startedAt || 0);
      batchingFixes = fixes.length > 1;
      for(const f of fixes){
        if(!currentTrip) break;
        if(!(f.timestamp > floorT)) continue;
        onFix({
          coords: { latitude: f.lat, longitude: f.lng, accuracy: f.accuracy, speed: f.speed, heading: f.heading, altitude: f.altitude },
          timestamp: f.timestamp
        });
      }
      if(batchingFixes && currentTrip){
        batchingFixes = false;
        renderLiveTrack();
        updateLiveStatDisplays();
        saveActiveTripCheckpoint();
      }
    }
  }catch(e){
    // Not fatal: anything left in the queue is picked up on the next event.
  }finally{
    batchingFixes = false;
    drainingSailFixes = false;
  }
}
async function startSailTracker(){
  const tracker = getSailTracker();
  try{
    if(!sailTrackerListenerAdded){
      await tracker.addListener('fixesAvailable', () => { drainSailTrackerFixes(); });
      sailTrackerListenerAdded = true;
    }
    // Safe to call when it's already running (e.g. the app was reopened
    // mid-journey): it just carries on recording.
    await tracker.start({ title: t('notification.recordingTitle'), text: t('notification.recordingBody'), intervalMs: 1000 });
    // Pick up anything recorded while the app was closed.
    drainSailTrackerFixes();
  }catch(e){
    nativeGpsActive = false;
    onGpsError();
  }
}
// Coming back to the app: collect whatever was recorded while it was hidden.
document.addEventListener('visibilitychange', () => {
  if(document.visibilityState === 'visible' && nativeGpsActive && useSailTracker()) drainSailTrackerFixes();
});

function startGPS(){
  document.getElementById('manualDistanceWrap').style.display='none';
  const gpsEl = document.getElementById('gpsStatus');
  renderLiveTrack();
  if(!('geolocation' in navigator)){
    gpsEl.textContent = t('gps.unavailable'); gpsEl.style.color='var(--coral)';
    document.getElementById('manualDistanceWrap').style.display='block';
    return;
  }
  gpsEl.textContent = t('gps.searching');
  lastFixTime = null;
  bestRejectedFix = null;
  pendingJumpCandidate = null;
  pendingMaxSpeedCandidate = null;
  const bgGeo = getBgGeo();
  if(useSailTracker()){
    nativeGpsActive = true;
    startSailTracker();
  } else if(isNativeApp() && bgGeo){
    nativeGpsActive = true;
    startNativeBackgroundGps(bgGeo);
  } else {
    // Web/PWA, or native without the plugin loaded for some reason —
    // foreground-only tracking. Reliable while the app is open and the
    // screen is on; does not survive the screen locking.
    watchId = navigator.geolocation.watchPosition(onFix, onGpsError, {enableHighAccuracy:true, maximumAge:2000, timeout:15000});
  }
  if(gpsWatchdogInterval) clearInterval(gpsWatchdogInterval);
  gpsWatchdogInterval = setInterval(checkGpsFreshness, 15000);
  // The native trackers show their own "Recording" notification; only the
  // web/PWA version needs this one (it used to show two in the app).
  if(!nativeGpsActive) showRecordingNotification();
}

async function startNativeBackgroundGps(bgGeo){
  try{
    // onLocation only needs wiring up once per app session — safe to call
    // again on a restart (e.g. from the watchdog), it just replaces the
    // previous listener rather than stacking duplicates.
    bgGeo.onLocation(
      (location) => onFix({ coords: location.coords, timestamp: location.timestamp }), // pass the fix's real GPS time through — see onFix()'s comment on why this matters for batched background fixes
      () => onGpsError()
    );
    if(!bgGeoReady){
      await bgGeo.ready({
        reset: true,
        geolocation: {
          desiredAccuracy: -1, // High — see DesiredAccuracy.High in the plugin's types; hardcoded since we can't import the enum without a bundler
          distanceFilter: 0,
          locationAuthorizationRequest: 'Always',
          stopOnStationary: false // sailing includes genuinely stationary stretches (anchored, drifting) — don't treat those as "trip over"
        },
        app: {
          stopOnTerminate: false,
          startOnBoot: true,
          notification: { title: t('notification.recordingTitle'), text: t('notification.recordingBody') }
        }
      });
      bgGeoReady = true;
    }
    await bgGeo.start();
  }catch(e){
    nativeGpsActive = false;
    onGpsError();
  }
}
// Mirrors the persistent "Trip Recording" system notification other tracking
// apps (SeePeople, etc.) show — makes it obvious at a glance, even with the
// phone locked or another app open, that a journey is currently being
// tracked. Best-effort: web notifications on Android Chrome behave a lot
// like this, but there's no true PWA equivalent of a native foreground
// service — the notification CAN be swiped away by the user without
// stopping tracking (a native app can pin theirs so it can't be dismissed;
// a web one can't). It also depends on notification permission being
// granted, and is more limited on iOS. The in-app recording banner stays as
// the reliable fallback either way — this is an addition to it, not a
// replacement.
async function showRecordingNotification(){
  try{
    if(!('serviceWorker' in navigator) || !('Notification' in window)) return;
    if(Notification.permission==='default'){ await Notification.requestPermission(); }
    if(Notification.permission!=='granted') return;
    const reg = await navigator.serviceWorker.ready;
    const boat = state.boats.find(b=>b.id===currentTrip?.boatId);
    reg.showNotification(t('notification.recordingTitle'), {
      body: boat ? t('notification.recordingBodyBoat', {boat: boat.name}) : t('notification.recordingBody'),
      icon: './images/icon-192.png',
      tag: 'trip-recording',
      silent: true
    });
  }catch(e){ /* not fatal — in-app recording banner is still there */ }
}
async function clearRecordingNotification(){
  try{
    if(!('serviceWorker' in navigator)) return;
    const reg = await navigator.serviceWorker.ready;
    (await reg.getNotifications({tag:'trip-recording'})).forEach(n=>n.close());
  }catch(e){}
}
function onFix(pos){
  lastFixTime = Date.now(); // processing time — used only to detect GPS going silent (checkGpsFreshness), never for distance/speed math
  const gpsEl = document.getElementById('gpsStatus');
  const acc = pos.coords.accuracy; // meters, browser's own confidence radius for this fix
  // Use the fix's own real GPS timestamp when we have one (native background
  // fixes can arrive in a batch, several at once, well after they were
  // actually recorded — timing them by Date.now() at processing time made
  // real gaps between points look near-instant, which made ordinary movement
  // look like impossibly fast jumps and get wrongly excluded from distance
  // and average-speed totals below). Falls back to Date.now() when a source
  // doesn't provide one (plain browser watchPosition doesn't need this fix,
  // since it never batches, but pos.timestamp is used there too if present).
  const fixTime = pos.timestamp ? new Date(pos.timestamp).getTime() : Date.now();
  const point = { lat: pos.coords.latitude, lng: pos.coords.longitude, t: fixTime, acc };

  if(acc != null && acc > GPS_ACCURACY_LIMIT_M){
    // Too imprecise to trust — keep it as a fallback candidate (in case signal
    // stays weak for a while and we'd otherwise record nothing at all) but
    // don't let it touch the path or stats.
    if(!bestRejectedFix || acc < bestRejectedFix.acc) bestRejectedFix = point;
    gpsEl.textContent = t('gps.weakSignal', {acc: Math.round(acc)});
    gpsEl.style.color = 'var(--coral)';
    return;
  }
  acceptFix(point);
}
// A fix implying a speed above this is almost certainly a GPS glitch, not
// real movement — but the right ceiling depends entirely on what's actually
// moving. Testing has moved from car to boat, so this is back down to a
// sailing-appropriate ceiling: 30kt comfortably covers even a foiling dinghy
// or fast catamaran while still catching genuine GPS jump glitches, which
// the old car-tuned 100kt ceiling let straight through.
const MAX_PLAUSIBLE_SPEED_KT = 30;
// Actually commits a fix to the trip: sanity-checks it against the previous
// accepted point and only THEN adds it to the path. A fix implying an
// impossible speed (see MAX_PLAUSIBLE_SPEED_KT above) is almost certainly a
// glitch, not real movement — but a plain "reject and wait" isn't enough on
// its own: the longer fixes keep getting rejected, the more elapsed time
// stacks up against that same stale last-good point, and distance÷time
// eventually dips back under the cutoff for ANY distance, however wrong —
// the filter quietly gets weaker over time instead of staying strict. That's
// what let a multi-mile jump back in after ~30s of "Ignored bad fix".
// Fix: once a fix gets rejected, we hold it as pendingJumpCandidate and stop
// trusting the stale-anchor math entirely — the ONLY way out of "disputed"
// state is a SECOND raw fix that closely agrees with the first rejected one
// (checked against each other, not the old anchor). Two fixes in a row
// landing in the same place is real, if abrupt, movement — e.g. GPS handing
// off between providers while another location app runs at the same time,
// which can happen even when each individual fix reports decent accuracy.
// An isolated one-off glitch won't have a second fix agreeing with it and
// just gets dropped. We don't count a confirmed jump's distance/speed toward
// trip stats, since we don't actually know the true path across whatever
// gap caused the dispute.
// Holds a single fast segment's speed until the NEXT segment either
// corroborates it (real burst — gets promoted to maxSpeed in commitFix) or
// fails to (lone GPS jitter spike — gets dropped). Reset alongside
// bestRejectedFix/pendingJumpCandidate at the start/end of every trip.
let pendingMaxSpeedCandidate = null;
function acceptFix(point){
  const prev = currentTrip.path[currentTrip.path.length-1];
  if(!prev){ commitFix(point, false); return; }

  const segNm = haversineNm(prev, point);
  const dtHours = (point.t - prev.t)/3600000;
  const instSpeed = dtHours>0 ? segNm/dtHours : Infinity;

  if(instSpeed < MAX_PLAUSIBLE_SPEED_KT && !pendingJumpCandidate){
    commitFix(point, true);
    return;
  }

  if(pendingJumpCandidate){
    const confirmNm = haversineNm(pendingJumpCandidate, point);
    const confirmDtHours = (point.t - pendingJumpCandidate.t)/3600000;
    const confirmSpeed = confirmDtHours>0 ? confirmNm/confirmDtHours : Infinity;
    if(confirmSpeed < MAX_PLAUSIBLE_SPEED_KT/4){ // much stricter — this is checking that TWO consecutive fixes agree with each other, not just against a stale anchor
      pendingJumpCandidate = null;
      commitFix(point, false); // confirmed relocation, but skip stats — the true path across the disputed gap is unknown
      return;
    }
  }
  pendingJumpCandidate = point;
  const gpsEl = document.getElementById('gpsStatus');
  gpsEl.textContent = t('gps.rejectedJump'); gpsEl.style.color='var(--coral)';
}
function commitFix(point, countStats){
  const gpsEl = document.getElementById('gpsStatus');
  const prev = currentTrip.path[currentTrip.path.length-1];
  if(countStats && prev){
    const segNm = haversineNm(prev, point);
    const dtHours = (point.t - prev.t)/3600000;
    if(dtHours>0){
      const instSpeed = segNm/dtHours;
      currentTrip.distanceNm += segNm;

      // A single two-point instant speed can spike from ordinary GPS jitter
      // — at typical sailing speeds, even a few meters of position error over
      // a short interval reads as a "fast" burst. A real burst of speed shows
      // up across consecutive fixes; a glitch doesn't. So a fast segment only
      // becomes the new max once the FOLLOWING segment corroborates it (at
      // least half as fast) — otherwise it's held as a candidate and dropped.
      if(pendingMaxSpeedCandidate){
        if(instSpeed > pendingMaxSpeedCandidate.speed*0.5){
          currentTrip.maxSpeed = Math.max(currentTrip.maxSpeed, pendingMaxSpeedCandidate.speed);
        }
        pendingMaxSpeedCandidate = null;
      }
      if(instSpeed > currentTrip.maxSpeed){
        pendingMaxSpeedCandidate = {speed: instSpeed};
      }
    }
  }
  currentTrip.path.push(point);
  bestRejectedFix = null;
  gpsEl.textContent = t('gps.live'); gpsEl.style.color='var(--navy)';
  const elapsedH = currentTrip.elapsedSeconds/3600;
  currentTrip.avgSpeed = elapsedH>0 ? currentTrip.distanceNm/elapsedH : 0;
  if(batchingFixes) return; // drainSailTrackerFixes() redraws + saves once at the end of the batch
  renderLiveTrack();
  updateLiveStatDisplays();
  saveActiveTripCheckpoint();
}
function onGpsError(){
  const gpsEl = document.getElementById('gpsStatus');
  gpsEl.textContent = t('gps.noSignal'); gpsEl.style.color='var(--coral)';
  document.getElementById('manualDistanceWrap').style.display='block';
  renderLiveTrack();
}
// Watchdog: polls how long it's been since ANY fix arrived (not just accepted
// ones). Past GPS_STALE_MS it visibly flags "no fix" in the GPS status pill
// instead of silently saying "Live" forever, and tries to self-heal by
// tearing down and restarting the watch — cheap to attempt, and covers the
// case where the OS/browser has quietly stalled the watch rather than the
// boat genuinely having no signal. If we've been stuck long enough and have a
// weak-but-real fallback fix sitting around, accept it rather than leaving a
// total gap in the track.
function checkGpsFreshness(){
  if(!currentTrip || currentTrip.isManual) return;
  if(watchId===null && !nativeGpsActive) return;
  if(!lastFixTime) return; // still waiting on the very first fix — "Searching…" already covers this
  const staleFor = Date.now() - lastFixTime;
  if(staleFor <= GPS_STALE_MS) return;

  const gpsEl = document.getElementById('gpsStatus');
  const mins = Math.floor(staleFor/60000), secs = Math.floor((staleFor%60000)/1000);
  gpsEl.textContent = t('gps.stale', {time: mins>0 ? `${mins}m ${secs}s` : `${secs}s`});
  gpsEl.style.color = 'var(--coral)';

  if(bestRejectedFix){
    acceptFix(bestRejectedFix);
    bestRejectedFix = null;
  }
  if(nativeGpsActive){
    // Tear down and restart the native watcher the same way we do for the
    // browser one below — cheap to attempt, and covers the case where the
    // watcher has quietly stalled rather than the boat genuinely having no
    // signal. ready() only needs calling once per session (bgGeoReady stays
    // true), so this restart is just stop() then start() again.
    if(useSailTracker()){
      // Collect anything waiting first, then ask the recorder to re-request GPS.
      // If the service has died altogether, start it again from scratch.
      drainSailTrackerFixes();
      getSailTracker().restart()
        .then(r => { if(!r || !r.running){ nativeGpsActive = false; startGPS(); } })
        .catch(() => {});
    } else {
      const bgGeo = getBgGeo();
      if(bgGeo) bgGeo.stop().finally(() => { nativeGpsActive = false; startGPS(); });
      else { nativeGpsActive = false; startGPS(); }
    }
  } else if('geolocation' in navigator){
    navigator.geolocation.clearWatch(watchId);
    watchId = navigator.geolocation.watchPosition(onFix, onGpsError, {enableHighAccuracy:true, maximumAge:2000, timeout:15000});
  }
}
function stopGPS(){
  if(watchId!==null && 'geolocation' in navigator){ navigator.geolocation.clearWatch(watchId); watchId=null; }
  if(nativeGpsActive){
    nativeGpsActive = false;
    if(useSailTracker()){
      getSailTracker().stop().catch(()=>{});
    } else {
      const bgGeo = getBgGeo();
      if(bgGeo) bgGeo.stop().catch(()=>{});
    }
  }
  if(timerId){ clearInterval(timerId); timerId=null; }
  if(gpsWatchdogInterval){ clearInterval(gpsWatchdogInterval); gpsWatchdogInterval=null; }
  lastFixTime = null;
  bestRejectedFix = null;
  pendingJumpCandidate = null;
  pendingMaxSpeedCandidate = null;
  clearRecordingNotification();
  stopLiveConnCheck();
  releaseWakeLock();
}
function confirmLeaveActive(){
  // Leaving the screen no longer stops tracking — GPS/timer keep running in the
  // background. The journey only ends when "End Journey" / "Save Log Entry" / "Save Changes" is pressed.
  nav('home');
  showToast(currentTrip.isEditing ? t('toast.editsKept') : currentTrip.isManual ? t('toast.draftKept') : t('toast.stillRecording'));
}
async function discardJourney(){
  const which = currentTrip.isEditing ? 'discardEdits' : currentTrip.isManual ? 'discardManual' : 'discardJourney';
  if(await confirmDialog(which, {danger:true, icon:'trash'})){
    stopGPS();
    const wasEditing = currentTrip.isEditing, editedId = currentTrip.id;
    currentTrip = null;
    clearActiveTripCheckpoint();
    document.getElementById('recordingBanner').classList.remove('show');
    if(wasEditing){ nav('history'); openTripDetail(editedId); } else { nav('home'); }
  }
}
/* ---- photos while logging: added via camera or upload tile, tap any thumb
   to set it as the cover, ✕ to remove. Compressed on add (see photo-store.js),
   max MAX_PHOTOS_PER_SAIL per sail. ---- */
// Optional reference map image for manual/edited entries, since there's no
// GPS track to draw for a past sail. Just a plain resize (not the crop
// adjuster) since the whole image content matters more than a tidy crop here.
async function handleMapImage(ev){
  const f = ev.target.files[0]; if(!f) return;
  ev.target.value = '';
  currentTrip.mapImage = await resizeImage(f, 1000, 0.8);
  document.getElementById('mapImagePreview').src = currentTrip.mapImage;
  document.getElementById('mapImagePreviewWrap').style.display = 'block';
}
function removeMapImage(){
  currentTrip.mapImage = null;
  document.getElementById('mapImagePreviewWrap').style.display = 'none';
}
// Photos are compressed on add (preparePhotoForSail in photo-store.js) and a
// sail holds at most MAX_PHOTOS_PER_SAIL. Older sails that already have more
// keep all of theirs — they just can't take any more.
async function handleActivePhotos(ev){
  const files = Array.from(ev.target.files||[]);
  ev.target.value='';
  if(!files.length) return;
  const room = MAX_PHOTOS_PER_SAIL - currentTrip.photos.length;
  if(room <= 0){ showToast(t('photos.limitReached', {max: MAX_PHOTOS_PER_SAIL})); return; }
  const accepted = files.slice(0, room);
  for(const f of accepted){
    try{
      const dataUrl = await preparePhotoForSail(f);
      currentTrip.photos.push(dataUrl);
      if(!currentTrip.coverPhoto) currentTrip.coverPhoto = dataUrl;
    }catch(e){ showToast(t('toast.photoProcessFail')); }
  }
  renderActivePhotoStrip();
  if(files.length > accepted.length) showToast(t('photos.limitPartial', {n: accepted.length, max: MAX_PHOTOS_PER_SAIL}));
}
function renderActivePhotoStrip(){
  const strip = document.getElementById('activePhotoStrip');
  strip.querySelectorAll('.photo-thumb').forEach(n=>n.remove());
  currentTrip.photos.forEach((p,i)=>{
    const div = document.createElement('div'); div.className='photo-thumb';
    div.innerHTML = `<img src="${safeSrc(p)}" onclick="setActiveCover(${i})">
      ${currentTrip.coverPhoto===p?`<div class="cover-badge">${t('active.coverBadge')}</div>`:''}
      <div class="rm" onclick="removeActivePhoto(${i})">✕</div>`;
    strip.insertBefore(div, strip.firstChild);
  });
  // Editing keeps the existing cover untouched by default (see endJourney) — this
  // link is the deliberate way to change it instead, rather than being forced
  // to re-pick on every save.
  const changeCoverLink = document.getElementById('changeCoverLink');
  if(changeCoverLink) changeCoverLink.style.display = (currentTrip.isEditing && currentTrip.photos.length) ? 'block' : 'none';
  // "12 / 20" counter in the card header; the add tiles fade once the sail is full.
  const n = currentTrip.photos.length, full = n >= MAX_PHOTOS_PER_SAIL;
  const counter = document.getElementById('activePhotoCount');
  if(counter){
    counter.textContent = t('photos.counter', {n, max: MAX_PHOTOS_PER_SAIL});
    counter.classList.toggle('full', full);
  }
  strip.querySelectorAll('.add-photo-tile').forEach(tile=> tile.classList.toggle('at-limit', full));
}
function setActiveCover(i){ currentTrip.coverPhoto = currentTrip.photos[i]; renderActivePhotoStrip(); }
function removeActivePhoto(i){
  const removed = currentTrip.photos.splice(i,1)[0];
  if(currentTrip.coverPhoto===removed) currentTrip.coverPhoto = currentTrip.photos[0]||null;
  renderActivePhotoStrip();
}

// The finish line for all three modes (live/manual/edit). Reads every form field
// into currentTrip, converting distance to canonical NM if the log was in metric.
// Then either prompts for a cover photo (if any were added) or saves straight away.
async function endJourney(){
  const which = currentTrip.isEditing ? 'saveChanges' : currentTrip.isManual ? 'savePastSail' : 'endJourney';
  if(!(await confirmDialog(which, {icon: currentTrip.isEditing || currentTrip.isManual ? 'check' : 'flag'}))) return;

  if(currentTrip.isManual){
    const hrs = parseFloat(document.getElementById('pastHours').value)||0;
    const mins = parseFloat(document.getElementById('pastMinutes').value)||0;
    const distInput = parseFloat(document.getElementById('pastDistance').value)||0;
    const dist = activeUnitSystem==='metric' ? distInput/NM_TO_KM : distInput; // convert to canonical NM
    const dateVal = document.getElementById('pastDate').value;
    currentTrip.elapsedSeconds = Math.round(hrs*3600 + mins*60);
    currentTrip.distanceNm = dist;
    const h = currentTrip.elapsedSeconds/3600;
    const autoAvg = h>0 ? dist/h : 0;
    // Avg/Max Speed default to the distance÷duration estimate, but a typed
    // value in either field (e.g. from a boat's own instruments) always wins.
    const avgInput = parseFloat(document.getElementById('pastAvgSpeed').value);
    const maxInput = parseFloat(document.getElementById('pastMaxSpeed').value);
    currentTrip.avgSpeed = !isNaN(avgInput) ? (activeUnitSystem==='metric' ? avgInput/KT_TO_KMH : avgInput) : autoAvg;
    currentTrip.maxSpeed = !isNaN(maxInput) ? (activeUnitSystem==='metric' ? maxInput/KT_TO_KMH : maxInput) : currentTrip.avgSpeed;
    currentTrip.date = dateVal ? new Date(dateVal).toISOString() : new Date().toISOString();
  } else {
    stopGPS();
    const manualInput = parseFloat(document.getElementById('manualDistance').value);
    if(!isNaN(manualInput) && (!currentTrip.path.length || currentTrip.distanceNm===0)){
      currentTrip.distanceNm = activeUnitSystem==='metric' ? manualInput/NM_TO_KM : manualInput; // canonical NM
      const h = currentTrip.elapsedSeconds/3600;
      currentTrip.avgSpeed = h>0 ? currentTrip.distanceNm/h : 0;
    }
  }
  currentTrip.weather = {
    sky: document.getElementById('sky').value,
    windDir: document.getElementById('windDir').value,
    windSpeed: parseFloat(document.getElementById('windSpeed').value)||0, // canonical kts
    gusts: parseFloat(document.getElementById('gusts').value)||0, // canonical kts
    waveDir: document.getElementById('waveDir').value,
    seaState: document.getElementById('seaState').value,
    waveHeight: document.getElementById('waveHeight').value,
    temp: document.getElementById('temp').value,
  };
  currentTrip.place = document.getElementById('tripPlace').value.trim();
  currentTrip.notes = document.getElementById('tripNotes').value;
  const boat = state.boats.find(b=>b.id===document.getElementById('activeBoatSelect').value);
  currentTrip.boatId = boat ? boat.id : null;
  const typedTitle = document.getElementById('tripTitle').value.trim();
  currentTrip._customTitle = !!typedTitle;
  currentTrip.title = typedTitle || (boat ? `Sail aboard ${boat.name}` : 'Untitled Sail');

  if(currentTrip.isEditing){
    // Editing keeps whatever cover was already set — no forced re-pick. Use the
    // "Change Cover Photo" link in the Photos section if you want to swap it.
    finalizeSaveTrip();
  } else if(currentTrip.photos && currentTrip.photos.length){
    openCoverPickSheet('onSave');
  } else {
    currentTrip.coverPhoto = null;
    finalizeSaveTrip();
  }
}
let coverPickMode = 'onSave'; // 'onSave' (part of finishing a new entry) | 'swap' (changing the cover mid-edit, doesn't save)
function openCoverPickSheet(mode){
  coverPickMode = mode || 'onSave';
  if(!currentTrip.photos || !currentTrip.photos.length){ showToast(t('toast.addPhotoFirst')); return; }
  // Default the selection to whatever's already the cover (editing) or the first photo, so
  // "Adjust Cover" has something sensible to work on even before the person taps a thumbnail.
  const existingIdx = currentTrip.photos.indexOf(currentTrip.coverPhoto);
  currentTrip._pickedCoverIndex = existingIdx>=0 ? existingIdx : 0;
  const strip = document.getElementById('coverPickStrip');
  strip.innerHTML = currentTrip.photos.map((p,i)=>`
    <div class="photo-thumb pickable${i===currentTrip._pickedCoverIndex?' selected':''}" data-i="${i}" onclick="pickCoverThumb(${i})">
      <img src="${safeSrc(p)}">
    </div>`).join('');
  document.getElementById('skipCoverPickBtn').style.display = coverPickMode==='onSave' ? 'block' : 'none';
  openSheet('sheetCoverPick');
}
function pickCoverThumb(i){
  document.querySelectorAll('#coverPickStrip .photo-thumb').forEach(n=>n.classList.remove('selected'));
  document.querySelector(`#coverPickStrip .photo-thumb[data-i="${i}"]`).classList.add('selected');
  currentTrip._pickedCoverIndex = i;
  currentTrip._coverAdjusted = false; // picking a different photo discards any crop made on the previous one
}
// Opens the rectangular crop/zoom adjuster on whichever photo is currently
// selected, matching the cover's actual wide-banner display shape. On confirm,
// confirmPhotoAdjust() sets currentTrip.coverPhoto directly (target:'cover'),
// which confirmCoverPick() below then respects instead of re-deriving from the
// raw, unedited photo array.
async function openCoverPhotoAdjuster(){
  const i = currentTrip._pickedCoverIndex ?? 0;
  // A photo already moved to cloud storage is a reference, not image data —
  // the crop tool needs the real image (from this device's copy, or the cloud).
  const src = await photoToDataUrl(currentTrip.photos[i]);
  if(!src){ showToast(t('toast.photoReadFail')); return; }
  currentTrip._coverAdjusted = true;
  startPhotoAdjuster(src, 'cover', 'sheetCoverPick', {shape:'rect', vw:320, vh:150, outputW:800, outputH:375});
}
function confirmCoverPick(){
  if(!currentTrip._coverAdjusted){
    const i = currentTrip._pickedCoverIndex;
    currentTrip.coverPhoto = (i!=null) ? currentTrip.photos[i] : (currentTrip.coverPhoto || currentTrip.photos[0]);
  } // else coverPhoto was already set by the adjuster — keep the cropped version
  delete currentTrip._pickedCoverIndex;
  delete currentTrip._coverAdjusted;
  closeSheets();
  if(coverPickMode==='onSave'){ finalizeSaveTrip(); }
  else { renderActivePhotoStrip(); showToast(t('toast.coverUpdated')); }
}
function skipCoverPick(){
  currentTrip.coverPhoto = null;
  delete currentTrip._pickedCoverIndex;
  delete currentTrip._coverAdjusted;
  closeSheets();
  if(coverPickMode==='onSave'){ finalizeSaveTrip(); }
  else { renderActivePhotoStrip(); showToast(t('toast.coverRemoved')); }
}
// The actual write to storage — shared by all three modes. Branches on
// isEditing to decide whether to overwrite the existing tripIndex entry in
// place or add a new one, since editing must never duplicate the trip.
async function finalizeSaveTrip(){
  // New sails: ask who can see it (Only me / Friends) — only when signed in,
  // since sharing needs an account. Edits keep their setting; it can be
  // changed any time from the chip at the top of the sail's page.
  if(!currentTrip.isEditing && !currentTrip.visibility){
    currentTrip.visibility = state.user ? await askTripVisibility() : 'private';
  }
  // A newly recorded GPS sail gets an automatic "Weather on the water" report
  // (see sail-weather.js) — marked waiting now, filled in once online.
  const needsWeatherReport = !currentTrip.isEditing && !currentTrip.isManual && wxHasTrack(currentTrip) && !currentTrip.weatherReport;
  if(needsWeatherReport) currentTrip.weatherReport = {status:'pending'};
  const savedBoat = currentTrip.boatId ? state.boats.find(b=>b.id===currentTrip.boatId) : null;
  currentTrip.boatName = savedBoat ? savedBoat.name : null; // shown to friends, who don't have your Fleet
  currentTrip.updatedAt = new Date().toISOString();
  const ok = await storeSet('trip:'+currentTrip.id, currentTrip);
  if(!ok){ showToast(t('toast.saveFailed')); return; }

  const indexEntry = {
    id: currentTrip.id, title: currentTrip.title, date: currentTrip.date,
    elapsedSeconds: currentTrip.elapsedSeconds, distanceNm: currentTrip.distanceNm,
    avgSpeed: currentTrip.avgSpeed, maxSpeed: currentTrip.maxSpeed,
    coverPhoto: currentTrip.coverPhoto, hasPhotos: currentTrip.photos.length>0,
    boatId: currentTrip.boatId, notes: currentTrip.notes, place: currentTrip.place,
    skipperId: currentTrip.skipperId||null
  };
  if(currentTrip.isEditing){
    const idx = state.tripIndex.findIndex(t=>t.id===currentTrip.id);
    if(idx>=0) state.tripIndex[idx] = indexEntry; else state.tripIndex.unshift(indexEntry);
  } else {
    state.tripIndex.unshift(indexEntry);
  }
  await storeSet(KEYS.INDEX, state.tripIndex);
  showToast(currentTrip.isEditing ? t('toast.changesSaved') : t('toast.journeySaved'));
  syncTripIfSignedIn(currentTrip);
  const savedId = currentTrip.id;
  currentTrip = null;
  clearActiveTripCheckpoint();
  nav('home');
  renderHomeStats();
  if(needsWeatherReport) await wxAddPending(savedId); // before opening, so an offline save is remembered
  openTripDetail(savedId);
}

/* ============================================================
   HISTORY
   ============================================================ */

/* ============================================================
   THEMED DATE & TIME PICKER — shared by the past-sail form and the Noticeboard form
   ------------------------------------------------------------
   Replaces the browser's own datetime-local widget (which ignored the app
   theme and, on Android, opened a plain spinner dialog). Tapping a Date/Time
   tap target opens #sheetDateTime with a month calendar and hour/minute
   scroll-wheels.

   The sheet edits a private draft (DT) and only hands the result back through
   DT.target.apply(dateStr, timeStr) when "Set" is tapped; Cancel/back discards it.
   A "target" describes who is asking:
     get()          -> {y,m,d,h,mi,hasTime} for the current value, or null if none yet
                       (m is 0-based, like JS Dates)
     apply(d, t)    -> called with 'YYYY-MM-DD' and 'HH:mm' ('' = no time chosen)
     optionalTime   -> true if a date without a time is a valid answer (Noticeboard)
     returnSheet    -> id of a sheet to reopen afterwards (Noticeboard form); null = just close
   For the past-sail form the value lives in a hidden <input type="datetime-local">
   (#pastDate, 'YYYY-MM-DDTHH:mm' local time) that endJourney()'s save code reads —
   anything that assigns #pastDate.value must call refreshPastDateDisplay() after.
   ============================================================ */
const DT_ITEM_PX = 44; // wheel row height — must match .wheel-item in the CSS
const DT = { y:0, m:0, d:1, h:0, mi:0, viewY:0, viewM:0, tab:'date', months:false, wheelsBuilt:false,
             target:null, hadTime:true, timeTouched:false };

// Locale for month/weekday names: the device's own locale when it matches the
// app language (so an en-GB phone gets "19 Sept 2026"), else the app's default.
function dtLocale(){
  const nav = (navigator.language || '').toLowerCase();
  return nav.startsWith(currentLang) ? navigator.language : currentLocale();
}
// First day of the week for the device's region, 0 = Sunday … 6 = Saturday.
function dtWeekStart(){
  try{
    const loc = new Intl.Locale(dtLocale());
    const wi = loc.getWeekInfo ? loc.getWeekInfo() : loc.weekInfo;
    if(wi && wi.firstDay) return wi.firstDay % 7; // Intl uses 1 = Mon … 7 = Sun
  }catch(e){}
  return currentLang==='he' ? 0 : 1;
}
const dtPad = n => String(n).padStart(2,'0');
function dtParse(v){ // 'YYYY-MM-DDTHH:mm' -> parts, or null
  const m = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})/.exec(v || '');
  return m ? {y:+m[1], m:+m[2]-1, d:+m[3], h:+m[4], mi:+m[5]} : null;
}
function dtParseDate(v){ // 'YYYY-MM-DD' (optionally followed by a time) -> {y,m,d}, or null
  const m = /^(\d{4})-(\d{2})-(\d{2})/.exec(v || '');
  return m ? {y:+m[1], m:+m[2]-1, d:+m[3]} : null;
}
function dtNowParts(){
  const n = new Date();
  return {y:n.getFullYear(), m:n.getMonth(), d:n.getDate(), h:n.getHours(), mi:n.getMinutes()};
}
function dtFmtDate(p, opts){ return new Intl.DateTimeFormat(dtLocale(), opts).format(new Date(p.y, p.m, p.d)); }

/* ---- past-sail form ---- */
// Shows the current #pastDate value on the two tap targets in the form.
function refreshPastDateDisplay(){
  const dEl = document.getElementById('pastDateDisplay'), tEl = document.getElementById('pastTimeDisplay');
  if(!dEl || !tEl) return;
  const p = dtParse(document.getElementById('pastDate').value);
  if(!p){ dEl.textContent = tEl.textContent = '—'; return; }
  dEl.textContent = dtFmtDate(p, {day:'numeric', month:'short', year:'numeric'});
  tEl.textContent = dtPad(p.h) + ':' + dtPad(p.mi);
}
function openDateTimeSheet(tab){
  dtOpen(tab, {
    get: ()=>{ const p = dtParse(document.getElementById('pastDate').value); return p ? Object.assign(p, {hasTime:true}) : null; },
    apply: (d, t)=>{ document.getElementById('pastDate').value = d + 'T' + t; refreshPastDateDisplay(); },
    optionalTime: false, returnSheet: null
  });
}

/* ---- the sheet itself ---- */
function dtOpen(tab, target){
  DT.target = target;
  const cur = target.get();
  const base = cur || Object.assign(dtNowParts(), {hasTime:false});
  DT.y = base.y; DT.m = base.m; DT.d = base.d;
  DT.hadTime = target.optionalTime ? !!(cur && cur.hasTime) : true;
  DT.h  = (cur && cur.hasTime) ? cur.h  : (target.optionalTime ? 9 : base.h);
  DT.mi = (cur && cur.hasTime) ? cur.mi : (target.optionalTime ? 0 : base.mi);
  DT.timeTouched = false;
  DT.viewY = DT.y; DT.viewM = DT.m; DT.months = false;
  if(!DT.wheelsBuilt){
    dtBuildWheel(document.getElementById('wheelHour'), 'h', 24);
    dtBuildWheel(document.getElementById('wheelMin'), 'mi', 60);
    DT.wheelsBuilt = true;
  }
  document.getElementById('dtClearTimeRow').style.display = target.optionalTime ? 'block' : 'none';
  openSheet('sheetDateTime');
  dtRenderDow();
  dtSetTab(tab || 'date');
}
function dtSetTab(tab){
  DT.tab = tab;
  document.getElementById('dtPaneDate').style.display = tab==='date' ? 'block' : 'none';
  document.getElementById('dtPaneTime').style.display = tab==='time' ? 'block' : 'none';
  document.getElementById('dtTabDate').classList.toggle('active', tab==='date');
  document.getElementById('dtTabTime').classList.toggle('active', tab==='time');
  dtRenderTabs();
  if(tab==='date') dtRenderCalendar();
  // A wheel can only be scrolled into position once it is actually visible.
  else requestAnimationFrame(()=>{ dtWheelSet(document.getElementById('wheelHour'), DT.h); dtWheelSet(document.getElementById('wheelMin'), DT.mi); });
}
function dtHasTime(){ return !DT.target.optionalTime || DT.hadTime || DT.timeTouched; }
function dtRenderTabs(){
  document.getElementById('dtTabDateVal').textContent = dtFmtDate(DT, {weekday:'short', day:'numeric', month:'short'});
  document.getElementById('dtTabTimeVal').textContent = dtHasTime() ? dtPad(DT.h) + ':' + dtPad(DT.mi) : t('noticeboard.anyTime');
}
function dtRenderDow(){
  const ws = dtWeekStart(), fmt = new Intl.DateTimeFormat(dtLocale(), {weekday:'narrow'});
  let html = '';
  for(let i=0;i<7;i++) html += '<span>' + fmt.format(new Date(2023, 0, 1 + (ws + i) % 7)) + '</span>'; // 1 Jan 2023 was a Sunday
  document.getElementById('calDow').innerHTML = html;
}
function dtRenderCalendar(){
  const title = document.getElementById('calTitle'), grid = document.getElementById('calGrid'),
        dow = document.getElementById('calDow'), months = document.getElementById('calMonths');
  const first = new Date(DT.viewY, DT.viewM, 1);
  grid.style.display = dow.style.display = DT.months ? 'none' : '';
  months.style.display = DT.months ? '' : 'none';
  if(DT.months){
    title.textContent = String(DT.viewY);
    const fmt = new Intl.DateTimeFormat(dtLocale(), {month:'short'});
    let mh = '';
    for(let i=0;i<12;i++) mh += '<button type="button" class="cal-month' + (DT.viewY===DT.y && i===DT.m ? ' sel' : '') + '" onclick="dtPickMonth(' + i + ')">' + fmt.format(new Date(DT.viewY, i, 1)) + '</button>';
    months.innerHTML = mh;
    return;
  }
  title.textContent = new Intl.DateTimeFormat(dtLocale(), {month:'long', year:'numeric'}).format(first);
  const lead = (first.getDay() - dtWeekStart() + 7) % 7;
  const dim = new Date(DT.viewY, DT.viewM + 1, 0).getDate();
  const now = new Date();
  let html = '';
  for(let i=0;i<lead;i++) html += '<span></span>';
  for(let d=1; d<=dim; d++){
    const isSel = DT.viewY===DT.y && DT.viewM===DT.m && d===DT.d;
    const isToday = DT.viewY===now.getFullYear() && DT.viewM===now.getMonth() && d===now.getDate();
    html += '<button type="button" class="cal-day' + (isSel ? ' sel' : isToday ? ' today' : '') + '" onclick="dtPickDay(' + d + ')">' + d + '</button>';
  }
  grid.innerHTML = html;
}
function dtNav(dir){ // ‹ › — a month at a time, or a year at a time in the month picker
  if(DT.months){ DT.viewY += dir; }
  else { DT.viewM += dir; if(DT.viewM < 0){ DT.viewM = 11; DT.viewY--; } else if(DT.viewM > 11){ DT.viewM = 0; DT.viewY++; } }
  dtRenderCalendar();
}
function dtToggleMonths(){ DT.months = !DT.months; dtRenderCalendar(); }
function dtPickMonth(i){ DT.viewM = i; DT.months = false; dtRenderCalendar(); }
function dtPickDay(d){
  DT.y = DT.viewY; DT.m = DT.viewM; DT.d = d;
  dtRenderCalendar(); dtRenderTabs();
}

// Scroll-snap wheel: rows are DT_ITEM_PX tall, the row centred under the
// highlight band is (scrollTop / DT_ITEM_PX) rounded.
function dtBuildWheel(el, key, count){
  let html = '';
  for(let i=0;i<count;i++) html += '<div class="wheel-item" data-i="' + i + '">' + dtPad(i) + '</div>';
  el.innerHTML = html;
  el._sel = -1;
  el.addEventListener('scroll', ()=>{
    cancelAnimationFrame(el._raf);
    el._raf = requestAnimationFrame(()=>{
      const i = Math.max(0, Math.min(count-1, Math.round(el.scrollTop / DT_ITEM_PX)));
      if(i !== el._sel){ dtWheelMark(el, i); DT[key] = i; DT.timeTouched = true; dtRenderTabs(); }
    });
  }, {passive:true});
  el.addEventListener('click', (e)=>{
    const it = e.target.closest('.wheel-item');
    if(it) el.scrollTo({top: (+it.dataset.i) * DT_ITEM_PX, behavior:'smooth'});
  });
}
function dtWheelMark(el, i){
  if(el._sel >= 0 && el.children[el._sel]) el.children[el._sel].classList.remove('sel');
  el._sel = i;
  if(el.children[i]) el.children[i].classList.add('sel');
}
function dtWheelSet(el, i){ dtWheelMark(el, i); el.scrollTop = i * DT_ITEM_PX; }

function dtNow(){
  Object.assign(DT, dtNowParts());
  DT.timeTouched = true;
  DT.viewY = DT.y; DT.viewM = DT.m; DT.months = false;
  dtSetTab(DT.tab);
}
// After Set/Cancel: back to the sheet that asked (Noticeboard form), or just close.
function dtFinish(){
  const back = DT.target && DT.target.returnSheet;
  if(back) openSheet(back); else closeSheets();
}
function dtCancel(){ dtFinish(); }
function dtApply(){
  const time = dtHasTime() ? dtPad(DT.h) + ':' + dtPad(DT.mi) : '';
  DT.target.apply(DT.y + '-' + dtPad(DT.m+1) + '-' + dtPad(DT.d), time);
  dtFinish();
}
// Noticeboard only: keep the date, drop the time ("any time that day")
function dtClearTime(){
  DT.hadTime = false; DT.timeTouched = false;
  dtApply();
}
